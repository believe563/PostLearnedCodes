package com.amap.indoor3d.demo.list;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import com.amap.indoor3d.demo.list.IndoorRequestBase.IndoorRequestCallBack;
import com.gaode.indoormap.model.IndoorBuilding;
import com.gaode.indoormap.request.IndoorErrorCode;

public class IndoorBuildingListRequest extends IndoorRequestBase implements
		IndoorRequestCallBack {

	private static final String requestPath = "ws/mapapi/indoor_maps_lite/";
	private List<IndoorBuilding> mBuildingList = new ArrayList<IndoorBuilding>();

	private IndoorBuildingListCallBack mBuildingListCallBack;

	public void setBuildingListCallBack(IndoorBuildingListCallBack callBack) {
		this.mBuildingListCallBack = callBack;
	}

	public IndoorBuildingListRequest(String requestUrl) {
		super(requestUrl, requestPath);
		this.setRequestCallBack(this);
	}

	public void setIndoorListParams() {
		// http://203.130.47.12:80/ws/mapapi/indoor_maps_lite/?from=indoorTest&compress=true&language=zh_cn&output=json&channel=autonavi&sign=1E361A3CACC34204A0E3497841DEF13C&
		if (this.mRequestMethod.equals("GET")) {
			StringBuffer params = new StringBuffer();
			params.append("?from=" + "indoor_demo_buildinglist" + "&")
					// android手机型号
					.append("compress=" + "true" + "&")
					// 请求压缩的数据
					.append("language=" + "zh_CN" + "&")
					.append("output=" + "json" + "&")
					.append("sign=" + "1E361A3CACC34204A0E3497841DEF13C" + "&")
					.append("channel=" + "autonavi" + "&")
					.append("servicetype=" + "autonavi" + "&")
					.append("Availability=" + "true");
			super.setRequestParams(params.toString());
		}
	}

	@Override
	public int OnResponseDataParse(JSONObject jsonObj) {
		int retCode = IndoorErrorCode.CLIENT_ERR_PARSE;
		try {
			retCode = super.onParse(jsonObj);
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		if (retCode == IndoorErrorCode.CLIENT_ERR_PARSE) {
			mBuildingListCallBack
					.onRetErrorCode(IndoorErrorCode.CLIENT_ERR_PARSE);
			this.mErrorCode = IndoorErrorCode.CLIENT_ERR_PARSE;
			return this.mErrorCode;
		}

		try {
			JSONArray array = jsonObj.optJSONArray("data");
			if (null != array) {
				int count = array.length();
				for (int i = 0; i < count; i++) {
					JSONObject obj = array.optJSONObject(i);
					IndoorBuilding building = new IndoorBuilding(obj.optString("_id"),obj.optString("Name"));
//					building.pid = obj.optString("_id");
//					building.name = obj.optString("Name");
					mBuildingList.add(building);
				}
			}
		} catch (Exception e) {
			this.mErrorCode = IndoorErrorCode.CLIENT_ERR_PARSE;
			mBuildingListCallBack
					.onRetErrorCode(IndoorErrorCode.CLIENT_ERR_PARSE);

			return this.mErrorCode;
		}

		this.mErrorCode = IndoorErrorCode.SUCCESS;
		mBuildingListCallBack.onFinishParseBuildList(mBuildingList);

		return this.mErrorCode;
	}

	@Override
	public int OnResponseError(int errorCode) {
		mBuildingListCallBack.onRetErrorCode(errorCode);
		return errorCode;
	}

	public interface IndoorBuildingListCallBack {
		/**
		 * @Title: onFinishParseBuild
		 * @Description:解析室内建筑物列表数据完成
		 */
		public void onFinishParseBuildList(List<IndoorBuilding> buildingList);

		/**
		 * @Title: onRetErrorCode
		 * @Description: 返回错误代码
		 * @param errorCode
		 */
		public void onRetErrorCode(int errorCode);
	}

	@Override
	public int OnResponseDataParse(byte[] byteArray) {

		return 0;
	}

}

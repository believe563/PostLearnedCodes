package com.amap.indoor3d.demo.net;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import com.gaode.indoormap.util.FileUtil;

public class PngRequest {
	public static String syncRequest(String url){
		HttpGet getMethod = new HttpGet("");  
		HttpClient httpClient = new DefaultHttpClient();  
		try {
		HttpResponse response =	httpClient.execute(getMethod);
		HttpEntity entity =  response.getEntity();
		String content = EntityUtils.getContentCharSet(entity);
		return content;
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public static void  request(final String url,final Response r){
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				HttpGet getMethod = new HttpGet(url);
				HttpClient httpClient = new DefaultHttpClient(); 
				InputStream input = null;
				ByteArrayOutputStream swapStream = null;
				try {
				HttpResponse response =	httpClient.execute(getMethod);
				HttpEntity entity =  response.getEntity();
				long len = entity.getContentLength();
				if(len>0){
					input = entity.getContent();
				    swapStream = new ByteArrayOutputStream(); 
					byte[] buff = new byte[100]; //buff用于存放循环读取的临时数据 
					int rc = 0; 
					while ((rc = input.read(buff, 0, 100)) > 0) { 
						swapStream.write(buff, 0, rc); 
					} 
					
					byte[] outputBuff = swapStream.toByteArray();
					if(r!=null){
						r.onResponse(outputBuff);
						File dstFile = new File("/sdcard/B023B1D4BX.bin");
						FileUtil.copyFile(outputBuff,dstFile);
						return;
					}
				}
				
				} catch (ClientProtocolException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}finally{
					if(input!=null){
						try {
							input.close();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
				if(r!=null){
					r.onResponse(null);
				}
			}
		}).start();
		
	}
	
	
	
	public static interface Response{
		public void onResponse(byte[] content);
	}
	
}

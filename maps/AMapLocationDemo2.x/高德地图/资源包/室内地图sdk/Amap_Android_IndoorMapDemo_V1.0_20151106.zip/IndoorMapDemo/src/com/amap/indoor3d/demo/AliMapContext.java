package com.amap.indoor3d.demo;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import com.gaode.indoormap.manager.IndoorDataManager;
import com.gaode.indoormap.mapview.IndoorMapView;
import com.taobao.mteam.blelocater.LocaterLocationNotify;
import com.taobao.mteam.blelocater.service.LocationData;


public class AliMapContext {
	private IndoorMapView mIMap;
	private IndoorDataManager mMapData;
	private String PID;
	private String Name;
	private Set<LocaterLocationNotify> locationNotifies = new HashSet<LocaterLocationNotify>();
	public AliMapContext() {
		
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getPID() {
		return PID;
	}

	public void setPID(String pID) {
		PID = pID;
	}

	public void setMap(IndoorMapView mIMap) {
		this.mIMap = mIMap;
	}

	private HashMap<String, Object> hashMap = new HashMap<String, Object>();
	
	public IndoorMapView getMapInterface(){
		return mIMap;
	}
	
	public void setMapData(IndoorDataManager mapData){
		this.mMapData = mapData;
	}
	
	public IndoorDataManager getMapData(){
		return mMapData;
	}
	
	public void addLocaterLocationNotify(LocaterLocationNotify notify ){
		synchronized (this) {
			locationNotifies.add(notify);
		}
	}
	
	public void removeLocaterLocationNotify(LocaterLocationNotify notify ){
		synchronized (this) {
			locationNotifies.remove(notify);
		}
	}
	
	public void onLocationNotify(LocationData data){
		synchronized (this) {
			for(LocaterLocationNotify notify:locationNotifies){
				notify.onLocationChanged(data);
			}
		}
	}
	
	protected void addService(String serviceName,Object service){
		hashMap.put(serviceName, service);
	}
	
	public Object getService(String serviceName){
		return hashMap.get(serviceName);
	}
	
	
}

/** Automatically generated file. DO NOT MODIFY */
package com.amap.map2d.demo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
package com.amap.indoor3d.demo.view;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.GridView;

public class IndoorGridView extends GridView {
	public IndoorGridView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public IndoorGridView(Context context) {
		super(context);
	}

	public IndoorGridView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	}

	@Override
	public void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		int expandSpec = MeasureSpec.makeMeasureSpec(Integer.MAX_VALUE >> 2,
				MeasureSpec.AT_MOST);
		super.onMeasure(widthMeasureSpec, expandSpec);
	}
}

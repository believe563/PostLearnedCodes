package com.amap.indoor3d.demo.adapter;
//package com.taobao.png.adapter;
//
//import java.util.List;
//
//import android.content.Context;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.BaseAdapter;
//import android.widget.TextView;
//
//import com.taobao.png.R;
//
//public class MallAdapter extends BaseAdapter{
//	List<MallData> mList;
//	Context mContext;
//	public MallAdapter(List<MallData> list,Context context) {
//		this.mList = list;
//		this.mContext = context;
//	}
//
//	@Override
//	public int getCount() {
//		return mList==null?0:mList.size();
//	}
//
//	@Override
//	public Object getItem(int arg0) {
//		return mList==null?null:mList.get(arg0);
//	}
//
//	@Override
//	public long getItemId(int arg0) {
//		return 0;
//	}
//
//	@Override
//	public View getView(int arg0, View arg1, ViewGroup arg2) {
//		View view = null;
//		if(view==null){
//			view = View.inflate(mContext, R.layout.aliglmap_mall_item, null);
//		}
//		TextView text =  (TextView)view.findViewById(R.id.text_floor);
//		MallData data = mList.get(arg0);
//		text.setText(data.name);
//		view.setTag(mList.get(arg0));
//		return view;
//	}
//
//}

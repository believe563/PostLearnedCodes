package com.amap.indoor3d.demo.model;

import java.io.Serializable;

import com.gaode.indoormap.mapview.FloorInfo;
import com.gaode.indoormap.mapview.PoiMapCell;

public class PoiInfo implements Serializable{
	private static final long serialVersionUID = 8589268912354164692L;
	public PoiMapCell cell;
	public FloorInfo floor;
	public String des;
}

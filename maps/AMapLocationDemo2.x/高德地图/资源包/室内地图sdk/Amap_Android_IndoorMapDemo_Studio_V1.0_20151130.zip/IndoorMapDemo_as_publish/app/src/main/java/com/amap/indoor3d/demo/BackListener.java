package com.amap.indoor3d.demo;

import android.os.Bundle;
import android.support.v4.app.Fragment;

public interface BackListener {
	public void onFragmentBackResult(Bundle bundle,int requstCode,Fragment from);
}

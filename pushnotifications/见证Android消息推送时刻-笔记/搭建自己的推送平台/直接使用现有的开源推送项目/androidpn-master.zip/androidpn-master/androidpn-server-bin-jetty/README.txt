ANDROIDPN-SERVER README
=======================
http://androidpn.sourceforge.net/

Push Notification Service for Android

This is an open source project to provide push notification support for Android
-- a xmpp based notification server and a client tool kit. 
package com.amap.indoor3d.demo;

import android.os.Bundle;

import com.gaode.indoormap.mapview.IndoorMapView;
import com.gaode.indoormap.util.FileUtil;
import com.taobao.png.R;

public class PngMainActivity extends MapBaseActivity {
	public static final String indoorPath = "/mnt/sdcard/Indoor.a";
	private IndoorMapView mMapView;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.aliglmap_layout_main);
//		Intent intent = getIntent();
//		String pid = intent.getStringExtra(IndoorListActivity.BUILDINGPOIID);
//		String name = intent.getStringExtra(IndoorListActivity.BUILDINGNAME);
		mMapView = (IndoorMapView) findViewById(R.id.aliglmap_mapview);
		AliMapContext context = new AliMapContext();
		context.setMap(mMapView);
		context.setPID("B000A856LJ");//pid
		context.setName("B000A856LJ");//name
		showFragment(new MainFragment(context, null), R.id.aliglmap_container,
				false);
	}
	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
	}
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
	}
	@Override
	protected void onDestroy() {
		mMapView.onDestroy();
		super.onDestroy();
	}
}

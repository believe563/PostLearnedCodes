package com.amap.indoor3d.demo;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.taobao.png.R;

public class MainActivity extends Activity {
	ListView listview;
	List<String> values;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.aliglmap_layout_start);
		// findViewById(R.id.btOne).setOnClickListener(this);
		// findViewById(R.id.btTwo).setOnClickListener(this);
		listview = (ListView) findViewById(R.id.listview);
		values = getData();
		listview.setAdapter(new ArrayAdapter<String>(this,
				android.R.layout.simple_expandable_list_item_1, values));
		listview.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				Intent intent = new Intent(MainActivity.this,
						PngMainActivity.class);
				intent.putExtra("PID", values.get(position));
				MainActivity.this.startActivity(intent);
			}
		});
	}

	private List<String> getData() {

		List<String> data = new ArrayList<String>();
		data.add("测试数据1");
		data.add("测试数据2");
		data.add("测试数据3");
		data.add("测试数据4");

		return data;
	}

}

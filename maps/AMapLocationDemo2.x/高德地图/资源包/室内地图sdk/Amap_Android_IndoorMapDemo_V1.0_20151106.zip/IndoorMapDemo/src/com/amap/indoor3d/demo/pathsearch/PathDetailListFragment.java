package com.amap.indoor3d.demo.pathsearch;

import java.util.ArrayList;
import java.util.HashMap;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

import com.amap.indoor3d.demo.AliMapContext;
import com.amap.indoor3d.demo.MapBaseFragment;
import com.amap.indoor3d.demo.Interface.BackListener;
import com.amap.indoor3d.demo.adapter.PathListAdapter;
import com.amap.indoor3d.demo.model.PoiInfo;
import com.taobao.png.R;

public class PathDetailListFragment extends MapBaseFragment implements OnClickListener{
	ListView mList;
	PathListAdapter mListAdapter;
	ArrayList<PoiInfo> mPathDetailList;
	HashMap<Integer,ArrayList<PoiInfo>> layerPoiArray;
	public PathDetailListFragment(AliMapContext context, BackListener from,ArrayList<PoiInfo> pathDetailList,HashMap<Integer,ArrayList<PoiInfo>> paths) {
		super(context, from);
		this.layerPoiArray = paths;
		mergeSamePoi(pathDetailList);
	}
	
	private void mergeSamePoi(ArrayList<PoiInfo> pathDetailList){
		mPathDetailList = new ArrayList<PoiInfo>();
		PoiInfo cur_index = null;
		for(PoiInfo info:pathDetailList){
			if(cur_index==null){
				mPathDetailList.add(info);
				cur_index = info;
			}else{
				if(!cur_index.cell.getName().equals(info.cell.getName())||cur_index.floor.fl_index!=info.floor.fl_index){
					mPathDetailList.add(info);
					cur_index = info;
				}
			}
		}
	}
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if(mPathDetailList!=null){
			mListAdapter = new PathListAdapter(mPathDetailList, getActivity());
		}
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view  = inflater.inflate(R.layout.aliglmap_layout_fsearchresult, null);
		mList = (ListView)view.findViewById(R.id.listview);
		mList.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				showFragment(new PathDetailMapFragment(getAliMapContext(), PathDetailListFragment.this,layerPoiArray, mPathDetailList,arg2), R.id.aliglmap_container, true);
			}
		});
		view.findViewById(R.id.btn_back).setOnClickListener(this);
		view.findViewById(R.id.btn_map).setOnClickListener(this);
		mList.setAdapter(mListAdapter);
		return view;
	}

	@Override
	public void onClick(View v) {
			switch(v.getId()){
			case R.id.btn_back:
				btnBack();
				break;
			case R.id.btn_map:
				btnShowMap();
				break;
			}
	}
	
	public void btnBack(){
		finish(null);
	}
	
	public void btnShowMap(){
		showFragment(new PathDetailMapFragment(getAliMapContext(), this, layerPoiArray,mPathDetailList, 0), R.id.aliglmap_container, true);
	}

}

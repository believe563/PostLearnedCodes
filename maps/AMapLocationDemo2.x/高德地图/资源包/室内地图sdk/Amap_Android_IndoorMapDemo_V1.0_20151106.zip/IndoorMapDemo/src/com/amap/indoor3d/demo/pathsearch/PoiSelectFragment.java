package com.amap.indoor3d.demo.pathsearch;

import java.util.List;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.TextView;

import com.amap.indoor3d.demo.AliMapContext;
import com.amap.indoor3d.demo.MapBaseFragment;
import com.amap.indoor3d.demo.Interface.BackListener;
import com.amap.indoor3d.demo.adapter.FloorAdapter;
import com.amap.indoor3d.demo.model.PoiInfo;
import com.gaode.indoormap.Listener.UserActionListener;
import com.gaode.indoormap.mapview.FloorInfo;
import com.gaode.indoormap.mapview.PoiMapCell;
import com.gaode.indoormap.mapview.PointD;
import com.taobao.png.R;


public class PoiSelectFragment extends MapBaseFragment implements OnClickListener{
	public final static String KEY_POI = "key_SearchFragment_poi";
	private PoiInfo mSingleSnapPoi;
	private ListView mList;
	private FloorAdapter mFloorAdapter;
	private TextView mTextPoi;
	public FloorInfo mCurrentFloor;
	public PoiSelectFragment(AliMapContext context,FloorInfo mCurrentFloor,BackListener back) {
		super(context,back);
		this.mCurrentFloor = mCurrentFloor;
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}
	
	@Override
	public void onResume() {
		super.onResume();
	}
	@Override
	public void onStart() {
		super.onStart();
		getMapInterface().setOnUserActionListener(new UserActionListener() {
			@Override
			public void onSingleTapUp(PointD point,int floorNum, List<PoiMapCell> poiList) {
				if (poiList==null || poiList.size()==0) {
					return;
				}
				PoiMapCell poiCell = poiList.get(0);
				if (poiCell==null) {
					return;
				}
				mTextPoi.setText(poiCell.getName());
				clearSingleSnapPoi();
				mSingleSnapPoi = new PoiInfo();
				mSingleSnapPoi.cell = poiCell;
				mSingleSnapPoi.floor = mCurrentFloor;
				poiCell.setResId(R.drawable.indoor_bubble_blue);
//				Drawable drawable= getActivity().getResources().getDrawable(R.drawable.aliglmap_indoor_pub_poi_select);
//				Bitmap bmp = BitmapFactory.decodeResource(getActivity().getResources(), R.drawable.aliglmap_indoor_pub_poi_select);
//				Rect rect=drawable.getBounds();
//				poiCell.setRect(new RectF(rect));
				poiCell.setGravity(PoiMapCell.BOTTOM_CENTER);
//				poiCell.setRect(new RectF(rect.left, rect.top, rect.right, rect.bottom));
				getMapInterface().addMarker(poiCell);
			}

			@Override
			public void onLongPressed(PointD point, int floorNum, List<PoiMapCell> poiList) {
			}

			@Override
			public void onClick(List<PoiMapCell> mark) {
				
			}
		});
	}
	
	@Override
	public void onStop() {
		super.onStop();
		getMapInterface().clearMarkers();
	}
	
	private void clearSingleSnapPoi() {
		if (mSingleSnapPoi != null) {
			getMapInterface().removeMarker(mSingleSnapPoi.cell);
		}
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view  = inflater.inflate(R.layout.aliglmap_layout_search, null);
		mList = (ListView)view.findViewById(R.id.list_floors);
		mFloorAdapter = new FloorAdapter(getAliMapContext().getMapInterface().getFloorList(), getActivity());
		mList.setAdapter(mFloorAdapter);
		view.findViewById(R.id.btn_back).setOnClickListener(this);
		view.findViewById(R.id.title).setOnClickListener(this);
		view.findViewById(R.id.btn_sure).setOnClickListener(this);
		mTextPoi = (TextView)view.findViewById(R.id.text_search);
		mList.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				FloorInfo data = (FloorInfo) arg1.getTag();
				mCurrentFloor = data;
				getMapInterface().loadMapFloor(data.fl_index);

			}

		});
		return view;
	}
	
	
	@Override
	public void onClick(View v) {
		switch(v.getId()){
		case R.id.btn_back:
			finish(null);
			break;
		case R.id.title:
			onSelectFloor();
			break;
		case R.id.btn_sure:
			btnSure();
			break;
		}
	}
	
	@Override
	public boolean interceptTouch(View arg0, MotionEvent arg1) {
		if (mList.getVisibility() == View.VISIBLE) {
			mList.setVisibility(View.INVISIBLE);
			return false;
		}
		return super.interceptTouch(arg0, arg1);
	}
	
	public void onSelectFloor(){
		if (mList.getVisibility() == View.VISIBLE) {
			mList.setVisibility(View.INVISIBLE);
		} else {
			mList.setVisibility(View.VISIBLE);
		}
	}
	
	public void btnSure(){
		Bundle bundle = new  Bundle();
		bundle.putSerializable(KEY_POI, mSingleSnapPoi);
		finish(bundle);
	}
	
}

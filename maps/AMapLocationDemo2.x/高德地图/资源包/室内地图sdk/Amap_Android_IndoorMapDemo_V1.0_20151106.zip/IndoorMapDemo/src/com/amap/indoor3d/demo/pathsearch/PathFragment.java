package com.amap.indoor3d.demo.pathsearch;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.amap.indoor3d.demo.AliMapContext;
import com.amap.indoor3d.demo.MapBaseFragment;
import com.amap.indoor3d.demo.Interface.BackListener;
import com.amap.indoor3d.demo.model.MapData;
import com.amap.indoor3d.demo.model.PoiInfo;
import com.gaode.indoormap.mapview.FloorInfo;
import com.gaode.indoormap.mapview.PoiMapCell;
import com.gaode.indoormap.mapview.PointD;
import com.gaode.indoormap.mapview.Segment;
import com.gaode.indoormap.model.RoutePathData;
import com.gaode.indoormap.request.IndoorRouteCallBack;
import com.gaode.indoormap.request.IndoorRouteRequest;
import com.gaode.indoormap.util.IndoorServer;
import com.gaode.indoormap.util.IndoorUtility;
import com.gaode.indoormap.util.MapLibLog;
import com.taobao.png.R;

/**
 * 路算
 * @author minghui.wang
 *
 */
public class PathFragment extends MapBaseFragment implements OnClickListener{
	private final static int REQUEST_CODE_POIFROM = 1001;
	private final static int REQUEST_CODE_POITO = 1002;
	Button mBtnFrom;
	Button mBtnTo;
	PoiSelectFragment mPoiSelectFragment;
	PoiInfo mInfoFrom;
	PoiInfo mInfoTo;
	ProgressDialog mProgressDialog;
	public PathFragment(AliMapContext context,BackListener back,Bundle bundle) {
		super(context,back);
		setArguments(bundle);
		int fid=context.getMapInterface().getFloorID();
		mPoiSelectFragment = new PoiSelectFragment(context,new FloorInfo("0","",fid),this);
	}
	public void setPoiInfoFrom(){
		setPoiInfoFrom(null);
	}
	public void setPoiInfoFrom(PoiInfo mInfoFrom){
		if(mInfoFrom==null){
			this.mInfoFrom =  loadMylocation();
		}else{
		this.mInfoFrom=mInfoFrom;
		}
		//refesh();
	}
	public void setPoiInfoTo(PoiInfo mInfoTo){
		this.mInfoTo=mInfoTo;
		//refesh();
	}
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = View.inflate(getActivity(), R.layout.aliglmap_layout_path, null);
		mBtnFrom = (Button)view.findViewById(R.id.btn_poifrom);
		mBtnTo = (Button)view.findViewById(R.id.btn_poito);
		view.findViewById(R.id.btn_back).setOnClickListener(this);
		view.findViewById(R.id.btn_search).setOnClickListener(this);
		view.findViewById(R.id.btn_mypoifrom).setOnClickListener(this);
		view.findViewById(R.id.btn_mypoito).setOnClickListener(this);
		view.findViewById(R.id.btn_back).setOnClickListener(this);
		mBtnFrom.setOnClickListener(this);
		mBtnTo.setOnClickListener(this);
//		mInfoFrom =  loadMylocation();
		refesh();
		return view;
	}
	
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}
	@Override
	public void onStart() {
		super.onStart();
	}
	
	@Override
	public void onStop() {
		super.onStop();
		clearPath();
	}
	
	private void clearPath(){
//		List<FloorData> list = getAliMapContext().getMapData().floorList;
//		for(FloorData data:list){
//			getMapInterface().setPathData(new ArrayList<PointD>(), data.fl_index);
//		}
	}

	private void refesh(){
		if(mInfoFrom!=null&& mInfoFrom.cell!=null){
			mBtnFrom.setText("  "+mInfoFrom.cell.getName());
		}
		if(mInfoTo!=null&&mInfoTo.cell!=null){
			mBtnTo.setText("  "+mInfoTo.cell.getName());
		}
	}

	@Override
	public void onClick(View v) {
		switch(v.getId()){
		case R.id.btn_poifrom:
			btnFrom();
			break;
		case R.id.btn_poito:
			btnTo();
			break;
		case R.id.btn_search:
			btnSearch();
			break;
		case R.id.btn_back:
			btnBack();
			break;
		case R.id.btn_mypoifrom:
			mInfoFrom =  loadMylocation();
			refesh();
			break;
		case R.id.btn_mypoito:
			mInfoTo =  loadMylocation();
			refesh();
			break;	
		}
	}
	/**
	 * 加载指定的位置
	 */
	private PoiInfo loadMylocation() {
		PoiInfo info = new PoiInfo();
		int floorID = 1;
		String namecode="F1";
		double x = 116.51863861083984, y = 39.924278259277344;
//		ScreenPointInfo screenInfo = getMapInterface().graphPoint2POI(x, y);
//		getMapInterface().updateLoc(x, y, floorID);
//		if (screenInfo.size() > 0) {
//			List<PoiMapCell> list = screenInfo.getPoiMapCells();
			info.cell = new PoiMapCell(61101,x, y,floorID,"我的位置");
			info.floor = new FloorInfo(namecode, "-1", floorID);
//		} else {
//			Toast.makeText(getActivity(), "未找到相应的对象", Toast.LENGTH_LONG).show();
//		}
		return info;
	}
	
	public void btnFrom(){
		 showFragment(mPoiSelectFragment, R.id.aliglmap_container,REQUEST_CODE_POIFROM, true);
	}
	
	
	public void btnTo(){
		showFragment(mPoiSelectFragment, R.id.aliglmap_container,REQUEST_CODE_POITO,true);
	}
	
	@Override
	public void onFragmentBackResult(Bundle bundle,int requestCode,Fragment from) {
		if(bundle!=null){
			PoiInfo  poiInfo = (PoiInfo)bundle.getSerializable(PoiSelectFragment.KEY_POI);
			if(poiInfo!=null){
				if(requestCode==REQUEST_CODE_POIFROM){
					mInfoFrom = poiInfo;
					Log.v("Path", mInfoFrom.toString());
				}else if(requestCode==REQUEST_CODE_POITO){
					mInfoTo = poiInfo;
					Log.v("Path", mInfoTo.toString());
				}
//				Log.v("Path", mInfoFrom.toString());
				refesh();
			}
		}
//		Toast.makeText(getActivity(), "fragment back", Toast.LENGTH_LONG).show();
	}
	
	private void showProgressDialog() {
		if (mProgressDialog == null) {
			mProgressDialog = new ProgressDialog(getActivity());
			mProgressDialog.setCancelable(false);
			mProgressDialog.show();
		} else {
			if (!mProgressDialog.isShowing()) {
				mProgressDialog.show();
				mProgressDialog.setCancelable(false);
			}
		}
	}

	private void dismissProgressDialog() {
		if (mProgressDialog != null) {
			if (mProgressDialog.isShowing()) {
				mProgressDialog.dismiss();
			}
		}
	}
	
	private void reFreshMap(int idx, RoutePathData routeInfoData){
		getMapInterface().setPathData(routeInfoData);
		mBtnFrom.post(new Runnable() {
			@Override
			public void run() {
				btnBack();		
			}
		});
		
	}
	
	public void btnSearch(){
		if(mInfoFrom==null){
			Toast.makeText(getActivity(), "请选择起始点", Toast.LENGTH_LONG).show();
			return;
		}
		if(mInfoTo==null){
			Toast.makeText(getActivity(), "请选择终点", Toast.LENGTH_LONG).show();
			return;
		}
		Segment[] segment=new Segment[1];
		IndoorRouteRequest request=new IndoorRouteRequest();
		String BuildingID=getAliMapContext().getPID();
		PointD start= new PointD(mInfoFrom.cell.getX(),mInfoFrom.cell.getY());
		PointD end= new PointD(mInfoTo.cell.getX(),mInfoTo.cell.getY());
		//segment[0]=new Segment(new PointD(mInfoFrom.cell.getX(),mInfoFrom.cell.getY()), new PointD(mInfoTo.cell.getX(),mInfoTo.cell.getY()), 0xff00ffff, 10);
//		getAliMapContext().getMapInterface().setSegments(segment,1);
		request.setRequestParams(getActivity(),BuildingID, mInfoFrom.cell.getFloorNo(), start, mInfoTo.cell.getFloorNo(), end);
		request.setRouteCallBack(new IndoorRouteCallBack() {
			@Override
			public void onRetRouteErrorCode(int errorCode,String msg) {
				Toast.makeText(getActivity(), "路算errorCode="+errorCode+":"+msg,Toast.LENGTH_LONG
						).show();
			}
			@Override
			public void onFinishParseRouteData(RoutePathData routeInfoData) {
				 reFreshMap(1,routeInfoData);
			}
		});
		request.startRequestTask();
	}
	public String getFrom()
	{
		return "miaojie";
	}
	/**
	 * 通过坐标->坐标导航
	 * @param buildingPoiId 大厦ID
	 * @param startFloorId 启动楼层ID
	 * @param mStartLocation 起点坐标
	 * @param stopfloor	到达楼层ID
	 * @param mStopLocation 终点坐标
	 */
	private String getRequestParams(String buildingPoiId, 
			PoiInfo mStartLocation, PoiInfo mStopLocation) {
		String startIdType = "3";// 3
		String stopIdType = "3";// 3
		buildingPoiId="B000ABBXKM";
		StringBuffer params = new StringBuffer();
		params.append(IndoorServer.getINDOORMAP_ROUTE_SERVER_ADDRESS());
		params.append("/ws/transfer/navigation/indoor?");
		params.append("?from=" + getFrom() + "&")
				.append("uuid=" + IndoorUtility.GetIMEI(null) + "&")
				// android手机型号
				.append("language=" + "zh_CN" + "&")
				.append("output=" + "json" + "&")
				.append("sign="
						+ IndoorUtility.getSignString("autonavi"
								+ buildingPoiId) + "&")
				.append("channel=" + "autonavi" + "&")
				.append("buildingid=" + buildingPoiId + "&")
				.append("charset=" + "utf8" + "&")
				.append("startfloor=" + mStartLocation.floor.fl_index + "&")
				.append("startx=" + mStartLocation.cell.getX() / 3600f + "&")
				.append("starty=" + mStartLocation.cell.getY() / 3600f + "&")
				.append("startidtype=" + startIdType + "&")
				.append("stopfloor=" + mStopLocation.floor.fl_index + "&")
				.append("stopx=" + mStopLocation.cell.getX() / 3600f + "&")
				.append("stopy=" + mStopLocation.cell.getY() / 3600f + "&")
				.append("stopidtype=" + stopIdType + "&")
				.append("Availability=" + "true");
		return params.toString();
	}
	public String generateMapRequestUrl(PoiInfo from, PoiInfo to, MapData map) {
		String url = "";
		if (map != null &&map.currentMall!=null&& !"".equals(map.currentMall.getMallPoid()) && from != null
				&& to != null) {
			url = IndoorServer.getINDOORMAP_ROUTE_SERVER_ADDRESS()+"/indoorroute?restype=1&buildingid="
					+ map.currentMall.getMallPoid()
					+ "&startidtype=3&startfloor="
					+ from.floor.fl_index
					+ "&startx="
					+ from.cell.getX()/3600f
					+ "&starty="
					+ from.cell.getY()/3600f
					+ "&stopidtype=3&stopfloor="
					+ to.floor.fl_index
					+ "&stopx="
					+ to.cell.getX()/3600f
					+ "&stopy="
					+ to.cell.getY()/3600f
					+ "8&TestMode=2&charset=utf-8&from=ali_guanger&_=1406724029939";
		}
		MapLibLog.Logv("url", url);
		return url;
	}
	
	public void btnBack(){
		finish(null);
	}

}

package com.amap.indoor3d.demo.list;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.zip.InflaterInputStream;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.HTTP;
import org.json.JSONObject;

import com.gaode.indoormap.request.IndoorErrorCode;
import com.gaode.indoormap.request.ThreadPoolUtils;
import com.gaode.indoormap.util.LogHelper;

public class IndoorRequestBase {
	protected static String TAG="IndoorRequestBase";
	// 执行返回错误代码
	protected int mErrorCode = IndoorErrorCode.SUCCESS;

	// 请求方式
	protected String mRequestMethod = "GET";

	// 请求URL
	private String mRequestUrl = "";

	// 请求路径
	private String mRequestPath = "";

	// 请求源
	private String mRequestSource = "indoor_test";

	// 请求数据格式:bin（二进制）或JSON
	private String mOutputFormat = "json";

	// 服务数据返回长度
	private int mOutputLength = 0;

	// GET请求参数
	private String mRequestParams = "";

	// POST请求参数
	protected List<NameValuePair> mPairParamList = null;

	// 额外请求参数
	private String mExtraParams = "";

	// 数据是否解压缩
	private boolean mParamCompress = false;

	// 网络访问超时时间
	private static final int REQUEST_TIMEOUT = 30 * 1000;

	private IndoorRequestCallBack mRequestCallBack;

	public void setRequestCallBack(IndoorRequestCallBack requestCallBack) {
		this.mRequestCallBack = requestCallBack;
	}
	/**
	 *  请求源
	 * @param mRequestSource
	 */
	public String getRequestSource() {
		return mRequestSource;
	}
	/**
	 *  请求源
	 * @param mRequestSource
	 */
	public void setRequestSource(String mRequestSource) {
		this.mRequestSource = mRequestSource;
	}

	public String getOutputFormat() {
		return mOutputFormat;
	}

	public void setOutputFormat(String mOutputFormat) {
		this.mOutputFormat = mOutputFormat;
	}

	public String getRequestUrl() {
		return mRequestUrl;
	}

	public void setRequestUrl(String mRequestUrl) {
		this.mRequestUrl = mRequestUrl;
	}

	public String getRequestParams() {
		return mRequestParams;
	}

	public void setRequestParams(String mRequestParams) {
		this.mRequestParams = mRequestParams;
	}

	public String getExtraParams() {
		return mExtraParams;
	}

	public void setExtraParams(String mExtraParams) {
		this.mExtraParams = mExtraParams;
	}

	public boolean isParamCompress() {
		return mParamCompress;
	}

	public void setParamCompress(boolean mParamCompress) {
		this.mParamCompress = mParamCompress;
	}

	public IndoorRequestBase(String url, String requestPath) {
		super();
		this.mRequestUrl = url;
		this.mRequestPath = requestPath;
	}

	public void startRequestTask() {
		ThreadPoolUtils.execute(new MyRunnable());
	}
	public int getErrorCode()
	{
		return mErrorCode;
	}
	private class MyRunnable implements Runnable {
		@Override
		public void run() {
			try {
				execRequestTask();
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}

	private int execRequestTask() {
		HttpResponse response = null;

		// 设置连接超时时间和数据读取超时时间
		HttpParams httpParams = new BasicHttpParams();
		HttpConnectionParams.setConnectionTimeout(httpParams, REQUEST_TIMEOUT);
		HttpConnectionParams.setSoTimeout(httpParams, REQUEST_TIMEOUT);
		String url="";
		if (mRequestMethod.equals("GET")) {
			String paramsStr = mRequestParams + mExtraParams;

//			String before_url = String.format("%s%s%s", mRequestUrl,
//					mRequestPath, paramsStr);
//			LogHelper.print("=========>indoor_unsecret_url:", before_url);

			url = String.format("%s%s%s", mRequestUrl, mRequestPath,
					paramsStr);
			LogHelper.print(TAG,"indoor_request_url="+url);
			
			try {
				// 生成请求对象
				HttpGet httpGet = new HttpGet(url);
				HttpClient httpClient = new DefaultHttpClient(httpParams);
				// 发送请求
				response = httpClient.execute(httpGet);
			} catch (Exception e) {
				mErrorCode = IndoorErrorCode.CLIENT_ERR_HTTP_CONNECT;
				return mRequestCallBack.OnResponseError(mErrorCode);
			}
		} else if (mRequestMethod.equals("POST")) {
			try {
				HttpEntity requestHttpEntity = new UrlEncodedFormEntity(
						this.mPairParamList, HTTP.UTF_8);

				// URL使用基本URL即可，其中不需要加参数
				HttpPost httpPost = new HttpPost(mRequestUrl
						+ this.mRequestPath);
				// 将请求体内容加入请求中
				httpPost.setEntity(requestHttpEntity);
				// 需要客户端对象来发送请求
				HttpClient httpClient = new DefaultHttpClient(httpParams);
				// 发送请求
				response = httpClient.execute(httpPost);
			} catch (Exception e) {
				mErrorCode = IndoorErrorCode.CLIENT_ERR_HTTP_CONNECT;
				return mRequestCallBack.OnResponseError(mErrorCode);
			}
		}

		if (response.getStatusLine().getStatusCode() != 200) {// 不成功
			mErrorCode = IndoorErrorCode.CLIENT_ERR_HTTP;
			return mRequestCallBack.OnResponseError(mErrorCode);
		}

		InputStream inputStream = getResponseStream(response);

		// 请求回来的数据是压缩的数据，需要解压
		if (mParamCompress) {
			if (this.mOutputFormat.equals("json")) {// JSON格式
				try {
					// 约定:跳过10个字节
					inputStream.skip(10);
					// 解压字节流,解压缩类的基类
					inputStream = new InflaterInputStream(inputStream);
				} catch (IOException e) {
					e.printStackTrace();
					mErrorCode = IndoorErrorCode.CLIENT_ERR_PARSE;
					return mRequestCallBack.OnResponseError(mErrorCode);
				}
			} else if (this.mOutputFormat.equals("bin")) {// bin格式：InputStream->byte[]
				LogHelper.print(TAG, "bin.mOutputLength" + this.mOutputLength);
			}
		}

		try {
			mErrorCode = parseResult(inputStream);
			inputStream.close();
		} catch (Exception e) {
			e.printStackTrace();
			return mRequestCallBack.OnResponseError(mErrorCode);
		} finally {
			inputStream = null;
		}

		return mErrorCode;
	}

	private InputStream getResponseStream(HttpResponse response) {
		if (null == response) {
			return null;
		}
		InputStream inputStream = null;
		HttpEntity httpEntity = response.getEntity();
		try {
			inputStream = httpEntity.getContent();
			mOutputLength = (int) httpEntity.getContentLength();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return inputStream;
	}

	private int parseResult(InputStream inputStream) {
		try {
			ByteArrayOutputStream output = new ByteArrayOutputStream();
			byte[] buffer = new byte[mOutputLength];
			int count = -1;
			while (-1 != (count = inputStream.read(buffer, 0, mOutputLength))) {
				output.write(buffer, 0, count);
			}
			output.flush();
			output.close();

			if (this.mOutputFormat.equals("json")) {// JSON格式
				JSONObject jsonObj = new JSONObject(new String(
						output.toByteArray(), "UTF-8"));
				return mRequestCallBack.OnResponseDataParse(jsonObj);
			} else if (this.mOutputFormat.equals("bin")) {// bin格式：InputStream->byte[]
				return mRequestCallBack.OnResponseDataParse(output
						.toByteArray());
			} else {
				mErrorCode = IndoorErrorCode.CLIENT_ERR_INDOOR_FORMAT_PARSE;
				return mErrorCode;
			}
		} catch (Exception e) {
			e.printStackTrace();
			mErrorCode = IndoorErrorCode.CLIENT_ERR_PARSE;
			return mErrorCode;
		}
	}

	/**
	 * @Title: onParse
	 * @Description: 解析返回数据状态是否正确
	 * @param jReader
	 * @return
	 */
	public int onParse(JSONObject jsonObj) throws IOException {
		String message = jsonObj.optString("message");
		if (null != message && message.equals("NO_NEW_DATA")) // 没有新数据，从缓存去取
			return IndoorErrorCode.INDOOR_NO_NEW_DATA;

		return IndoorErrorCode.SUCCESS;
	}

	public interface IndoorRequestCallBack {
		/**
		 * @brief 解析输入流(JSON)
		 * @param json
		 *            :代表返回数据的JSON根对象
		 */
		abstract int OnResponseDataParse(JSONObject json);

		/**
		 * @brief 解析二进制输入流(byteArray)
		 * @param json
		 *            :代表返回数据的数据流(字节数组)
		 */
		abstract int OnResponseDataParse(byte[] byteArray);

		/**
		 * @Title: OnResponseError
		 * @Description: 请求过程中返回错误代码
		 * @param errorCode
		 *            :错误代码
		 * @return
		 */
		abstract int OnResponseError(int errorCode);
	}

}

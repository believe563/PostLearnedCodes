package com.amap.indoor3d.demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.amap.indoor3d.demo.Interface.BackListener;
import com.amap.indoor3d.demo.view.IndoorEditText;
import com.amap.indoor3d.demo.view.IndoorEditTextWatcherEventListener;
import com.amap.indoor3d.demo.view.IndoorGridView;
import com.amap.indoor3d.demo.view.IndoorSearchListAdapter;
import com.gaode.indoormap.manager.IndoorDataManager;
import com.gaode.indoormap.mapview.FloorInfo;
import com.gaode.indoormap.mapview.PoiMapCell;
import com.gaode.indoormap.sdk.binary.v3.ClassInfo;
import com.gaode.indoormap.searchengine.IndoorE;
import com.gaode.indoormap.searchengine.IndoorSearchManager;
import com.gaode.indoormap.util.IndoorUtility;
import com.taobao.png.R;

/**
 * @ClassName: IndoorSearchActivity
 * @Description: 室内搜索
 * @author wmh
 * @date 2015-09-30
 * @version 1.0
 */
public class IndoorSearchActivity extends MapBaseFragment implements OnClickListener,
		OnTouchListener {
	public final static String KEY_TYPE = "key_Search_type";
	public final static String KEY_TYPE_PUB = "key_Search_pub";
	public final static String KEY_TYPE_KEY = "key_Search_key";
	public final static String KEY_REQUEST = "key_Search_request";
	
	private Context mContext;
	private ProgressDialog mLoadingDialog;
	private View mSearchView;
	private ImageButton mSearchBack;
	private TextView mSearchText;

	private LinearLayout mBussinessLayout;
	private TextView mBussinessTextView;
	private IndoorGridView mBussinessGridView;
	private LinearLayout mPubLayout;
	private IndoorGridView mServiceGridView;
	private View mSearchResultView;
	private View view;
	// 搜索结果列表
	private ImageButton mSearchResultBack;
	private IndoorEditText mSearchEditText;
	private ImageButton mSearchClearBtn;
	private TextView mSearchResultTips;
	private ListView mSearchListView;
	private IndoorSearchListAdapter mListViewAdapter = null;
	private IndoorDataManager mDataManager;
	private IndoorSearchManager searchmanager=new IndoorSearchManager();
	private List<ClassInfo> mShopTypes=new ArrayList<ClassInfo>();
	private List<ClassInfo> pubTypes=new ArrayList<ClassInfo>();
	private Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			if (msg.what == 1000) {
				initGridView();
			}
		}
	};
//	public static void StartActivity(Context ctx){
////		Intent intent= new Intent(ctx, IndoorSearchActivity.class);
////		ctx.startActivity(intent);
//		PathFragment pathFragment = new PathFragment(getAliMapContext(), this,
//				null);
//		showFragment(pathFragment, R.id.aliglmap_container, true);
//	}
	private MainFragment fragment;
	public IndoorSearchActivity(AliMapContext context,MainFragment fragment,BackListener back,Bundle bundle) {
		super(context,back);
		setArguments(bundle);
		this.fragment=fragment;
	}
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container) {
//		super.onCreate(savedInstanceState);
//		requestWindowFeature(Window.FEATURE_NO_TITLE);
//		setContentView(R.layout.activity_indoor_search);
		view = View.inflate(getActivity(), R.layout.activity_indoor_search, null);
		mContext = getActivity();
		mDataManager=MainFragment.mIndoorManager;
		searchmanager.init(getActivity(), mDataManager.getIndoorBuilding());
		// 搜索分类
		initSearchTopBar();
		// 搜索结果列表
		initSearchResultView();
		initGridView();
		return view;
	}

	/**
	 * @Title: initSearchTopBar
	 * @Description: 初始化室内搜索顶部Bar
	 */
	private void initSearchTopBar() {
		mSearchView = view.findViewById(R.id.indoor_search_view);

		mSearchBack = (ImageButton) mSearchView
				.findViewById(R.id.indoor_search_category_btn_back);
		mSearchBack.setOnClickListener(this);

		mSearchText = (TextView) mSearchView
				.findViewById(R.id.indoor_search_category_textview);
		mSearchText.setOnClickListener(this);
	}

	/**
	 * @Title: initGridView
	 * @Description:初始化室内GridView
	 */
	private void initGridView() {
		dismissLoadingDialog();
		mShopTypes.clear();
		pubTypes.clear();
		// 初始化精品商家
		mBussinessLayout = (LinearLayout) mSearchView
				.findViewById(R.id.indoor_bussiness_layout);
		
		mBussinessTextView = (TextView) mSearchView
				.findViewById(R.id.indoor_bussiness_textview);

		mBussinessGridView = (IndoorGridView) mSearchView
				.findViewById(R.id.indoor_business_gridview);
		ClassInfo[] mAllTypes=searchmanager.getClassList();
		for (ClassInfo info : mAllTypes) {
			String amType = info.getClassfyType();
			if (amType.equals("AM1002")||amType.equals("AM1004")||amType.equals("AM1005")||amType.equals("AM1009")||amType.equals("AM1010")||amType.equals("AM1011")||amType.equals("AM1012")||amType.equals("AM1013")) {
				pubTypes.add(info);
			} else {
				if (amType.equals("AM0010")){
					mShopTypes.add(0,info);
				}else{
					mShopTypes.add(info);
				}
			}
		}
		
		if (null != mShopTypes && mShopTypes.size() > 0) {
			List<HashMap<String, Object>> mShopTypeList = new ArrayList<HashMap<String, Object>>();
			for (int i = 0; i < mShopTypes.size(); i++) {
				ClassInfo shopType = mShopTypes.get(i);
				String iconName = shopType.getClassfyType().toLowerCase();
				String typeName = shopType.getClassfyName();
				int iconId = this.getResources()
						.getIdentifier("indoor_" + iconName, "drawable",
								getActivity().getPackageName());
				if (iconId > 0) {
					HashMap<String, Object> resHashMap = new HashMap<String, Object>();
					resHashMap.put("icon", iconId);
					resHashMap.put("name", typeName);
					resHashMap.put("type", iconName);
					resHashMap.put("obj", shopType);
					mShopTypeList.add(resHashMap);
				}
			}

			SimpleAdapter bussinessAdapter = new SimpleAdapter(mContext,
					mShopTypeList, R.layout.indoor_gridview_item, new String[] {
							"icon", "name" }, new int[] {
							R.id.gridview_item_image, R.id.gridview_item_text });

			mBussinessGridView.setAdapter(bussinessAdapter);
			mBussinessGridView
					.setOnItemClickListener(mBussinessItemClickListener);

			// if (mDataManager.getIndoorBuilding().mAutoNaviType / 10000 == 6)
			// {// 购物类建筑
			// mBussinessTextView.setText("精品商家");
			// } else {
			// mBussinessTextView.setText("服务分类");
			// }
			mBussinessTextView.setText("服务分类");
			mBussinessLayout.setVisibility(View.VISIBLE);
		} else {
			mBussinessLayout.setVisibility(View.GONE);
		}

		// 初始化公共服务设施
		mPubLayout = (LinearLayout) mSearchView
				.findViewById(R.id.indoor_service_layout);
		mServiceGridView = (IndoorGridView) mSearchView
				.findViewById(R.id.indoor_service_gridview);
		
//		List<ClassfyInfo> pubTypes = mDataManager
//				.getIndoorBuilding().mAllPubCategory;
		if (pubTypes.size() > 0) {
			List<HashMap<String, Object>> serviceList = new ArrayList<HashMap<String, Object>>();
			for (int i = 0; i < pubTypes.size(); i++) {
				ClassInfo pubType = pubTypes.get(i);
				String iconName = pubType.getClassfyType().toLowerCase();
				String typeName = pubType.getClassfyName();
				int iconId = this.getResources()
						.getIdentifier("indoor_" + iconName, "drawable",
								getActivity().getPackageName());
//				if (iconId > 0) 
				{
					HashMap<String, Object> resHashMap = new HashMap<String, Object>();
					resHashMap.put("icon", iconId);
					resHashMap.put("name", typeName);
					resHashMap.put("type", iconName);
					resHashMap.put("obj", pubType);
					serviceList.add(resHashMap);
				}
			}

			SimpleAdapter serviceAdapter = new SimpleAdapter(mContext,
					serviceList, R.layout.indoor_gridview_item, new String[] {
							"icon", "name" }, new int[] {
							R.id.gridview_item_image, R.id.gridview_item_text });

			mServiceGridView.setAdapter(serviceAdapter);
			mServiceGridView.setOnItemClickListener(mServiceItemClickListener);
			mPubLayout.setVisibility(View.VISIBLE);
		} else {
			mPubLayout.setVisibility(View.GONE);
		}
	}

	/**
	 * @Title: initSearchResultView
	 * @Description: 初始化室内搜索结果列表视图
	 */
	private void initSearchResultView() {
		mSearchResultView = view.findViewById(R.id.indoor_search_result_view);

		mSearchResultBack = (ImageButton) mSearchResultView
				.findViewById(R.id.indoor_search_result_btn_back);

		mSearchResultBack.setOnClickListener(this);

		mSearchEditText = (IndoorEditText) mSearchResultView
				.findViewById(R.id.indoor_search_edittext);

		setEditTextEventListener();

		mSearchClearBtn = (ImageButton) mSearchResultView
				.findViewById(R.id.indoor_search_edittext_clear_btn);
		mSearchClearBtn.setOnClickListener(this);

		mSearchResultTips = (TextView) mSearchResultView
				.findViewById(R.id.indoor_search_result_tip);
		mSearchListView = (ListView) mSearchResultView
				.findViewById(R.id.indoor_search_result_list);
		mSearchListView.setOnTouchListener(this);
		mSearchListView.setOnItemClickListener(mSearchListItemClickListener);

		mListViewAdapter = new IndoorSearchListAdapter(mContext, true);
		mSearchListView.setAdapter(mListViewAdapter);
	}

	/**
	 * 点击商家监听事件:跳到搜索结果列表显示
	 */
	private OnItemClickListener mBussinessItemClickListener = new OnItemClickListener() {
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {
			@SuppressWarnings("unchecked")
			HashMap<String, Object> itemMap = (HashMap<String, Object>) parent
					.getAdapter().getItem(position);
			if (null != itemMap && itemMap.get("type") != null) {
				String sndtType = itemMap.get("type").toString();
				ClassInfo shopType=(ClassInfo)itemMap.get("obj");
				mSearchResultView.setVisibility(View.VISIBLE);
				loadSearchListByType(shopType);
			}
		}
	};

	/**
	 * 点击公共设施监听事件:直接回到地图高亮显示
	 */
	private OnItemClickListener mServiceItemClickListener = new OnItemClickListener() {
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {
			HashMap<String, Object> itemMap = (HashMap<String, Object>) parent
					.getAdapter().getItem(position);
			if(itemMap==null){
				return;
			}
			int floorId=getMapInterface().getFloorID();
			ClassInfo shopType=(ClassInfo)itemMap.get("obj");
			List<IndoorE> resultList=new ArrayList<IndoorE>();
			for (Integer nType : shopType.getSubTypeList()) {
				resultList.addAll(searchmanager.searchType(nType,
						floorId));
			}
			if (resultList.size() == 0) {
				List<FloorInfo> list = getMapInterface().getFloorList();
				for (int i = 0; i < list.size(); i++) {
					floorId = list.get(i).fl_index;
					for (Integer nType : shopType.getSubTypeList()) {
						resultList.addAll(searchmanager.searchType(nType,
								floorId));
					}
					if (resultList.size() > 0) {
						break;
					}
				}
			}
			if (resultList.size() > 0) {
				IndoorE indoorE=resultList.get(0);
				getMapInterface().loadMapFloor(floorId);
				getMapInterface().setViewPortToLocation(indoorE.nCenterX,indoorE.nCenterY);
			}
			getMapInterface().clearMarkers();
			for (IndoorE indoorE : resultList) {
				if (indoorE != null) {
					PoiMapCell poiCell = new PoiMapCell(indoorE.nTypeCode,
							indoorE.nCenterX, indoorE.nCenterY,
							indoorE.strName_dp);
					poiCell.setClickable(true);
					poiCell.setGravity(PoiMapCell.BOTTOM_CENTER);
					poiCell.setResId(R.drawable.indoor_bubble_red);
					int result = getMapInterface().addMarker(poiCell);
					Log.v("wmh", "addMarker result=" + result);
				}
			}
			Bundle bundle = new  Bundle();
			bundle.putString(KEY_TYPE, KEY_TYPE_PUB);
			bundle.putSerializable(KEY_REQUEST, itemMap);
			finish(bundle);
		}
	};

	/**
	 * 搜索结果列表每项点击事件：回到地图高亮显示
	 */
	private OnItemClickListener mSearchListItemClickListener = new OnItemClickListener() {
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {
			IndoorE indoorE = mListViewAdapter.getItem(position);
			if (indoorE != null) {
				getMapInterface().clearMarkers();
//				ScreenPointInfo pointInfo = JniGLMapRenderer.graphPoint2POI(
//						indoorE.nCenterX, indoorE.nCenterY);
//				List<PoiMapCell> list=pointInfo.getPoiMapCells();
				PoiMapCell poiCell=null;
//				if(pointInfo.size()>0){
//					poiCell=pointInfo.getPoiMapCells().get(0);
//				}
//				else{
					poiCell = new PoiMapCell(indoorE.nTypeCode,
						indoorE.nCenterX, indoorE.nCenterY, indoorE.strName_dp);
//				}
//				poiCell=JniGLMapRenderer.search(""+indoorE.strSID);
				poiCell.setFloorNo(indoorE.nFloorIndex);
				poiCell.setClickable(true);
				poiCell.setGravity(PoiMapCell.BOTTOM_CENTER);
				poiCell.setResId(R.drawable.indoor_bubble_red);
				getMapInterface().loadMapFloor(indoorE.nFloorIndex);
				fragment.addMarker(poiCell);
				getMapInterface().setViewPortToLocation(poiCell.getX(),poiCell.getY());
				//int result = getMapInterface().addMarker(poiCell);
				//Log.v("wmh", "addMarker result=" + result);
				finish(null);
			} else {
				Toast.makeText(getActivity(), "找不到相应的店铺", Toast.LENGTH_LONG)
						.show();
			}
		}
	};

	/**
	 * @Title: loadSearchListByType
	 * @Description: 通过精品商家类别加载搜索列表
	 */
	private void loadSearchListByType(ClassInfo shopType) {
//		if (null == myDBHelper)
//			return;
		List<IndoorE> resultList=new ArrayList<IndoorE>();
		for(Integer nType:shopType.getSubTypeList()){
			resultList.addAll(searchmanager.searchType(nType));
		}
//		List<IndoorSearchResult> resultList = mDataManager
//				.selectBySNDTType(mDataManager.getBuildingPoiId(),sndtTypte);

		if (null != resultList && resultList.size() > 0) {
			int iconId = this.getResources().getIdentifier(
					getActivity().getPackageName() + ":drawable/"
							+ ("indoor_" + shopType.getClassfyType()), null, null);
			mListViewAdapter.notifyListByType(iconId, resultList);
			//https://testing.autonavi.com/browse/AMAPNEW-7757：室内搜索某个精品商家，拖动到下面，然后搜索其他的精品，应该仍然直接显示顶部
			mSearchListView.setSelection(0);
			mSearchListView.setVisibility(View.VISIBLE);
		} else {
			Toast.makeText(mContext, "未查询到结果", Toast.LENGTH_SHORT).show();
		}
	}

	/**
	 * @Title: loadSearchListByKeywords
	 * @Description: 加载搜索关键字列表
	 * @param keywords
	 */
	private void loadSearchListByKeywords(final String keywords) {
//		if (null == myDBHelper)
//			return;

//		List<IndoorSearchResult> resultList = myDBHelper
//				.selectByKeywords(keywords);
		//List<IndoorSearchResult> resultList = mDataManager.searchIndoorMap(mDataManager.getBuildingPoiId(), keywords);
		List<IndoorE> resultList =searchmanager.search(keywords);
		if (null != resultList) {
			mListViewAdapter.notifyListByKeywords(keywords, resultList);
			if (resultList.size() == 0) {
				mSearchResultTips.setVisibility(View.VISIBLE);
				mSearchListView.setVisibility(View.GONE);
			} else {
				mSearchResultTips.setVisibility(View.GONE);
				mSearchListView.setVisibility(View.VISIBLE);
			}
		} else {
			mSearchResultTips.setVisibility(View.VISIBLE);
		}
	}

	/**
	 * @Title: showSoftInput
	 * @Description: 显示输入键盘
	 */
	private void showSoftInput() {
		mSearchEditText.setFocusable(true);
		mSearchEditText.setFocusableInTouchMode(true);
		mSearchEditText.requestFocus();

		new Handler().postDelayed(new Runnable() {
			@Override
			public void run() {
				InputMethodManager inputManager = (InputMethodManager) mSearchEditText
						.getContext().getSystemService(
								Context.INPUT_METHOD_SERVICE);
				inputManager.showSoftInput(mSearchEditText, 0);
			}
		}, 100);
	}

	/**
	 * @Title: setEditTextEventListener
	 * @Description: 设置EditText监听事件
	 */
	private void setEditTextEventListener() {
		mSearchEditText
				.setOnEditorActionListener(new TextView.OnEditorActionListener() {
					@Override
					public boolean onEditorAction(TextView v, int actionId,
							KeyEvent event) {
						if (actionId == EditorInfo.IME_ACTION_SEARCH) {
							String keywords = mSearchEditText.getText()
									.toString().trim();
							if (!TextUtils.isEmpty(keywords)) {
								loadSearchListByKeywords(mSearchEditText
										.getText().toString().trim());
								IndoorUtility.hideInputMethod(mContext, v);
							}

							return true;
						}

						return false;
					}
				});

		mSearchEditText
				.setTextWatcherEventListener(new IndoorEditTextWatcherEventListener() {
					private int selectionStart;
					private int selectionEnd;

					@Override
					public void afterTextChanged(View view, Editable s) {
						selectionStart = mSearchEditText.getSelectionStart();
						selectionEnd = mSearchEditText.getSelectionEnd();

						if (s.length() > 0) {
							mSearchClearBtn.setVisibility(View.VISIBLE);
						} else if (s.length() == 0) {
							mSearchClearBtn.setVisibility(View.GONE);
						} else if (s.length() > 20) {
							s.delete(selectionStart - 1, selectionEnd);
							int tempSelection = selectionEnd;
							mSearchEditText.setText(s);
							mSearchEditText.setSelection(tempSelection);// 设置光标在最后
						}
					}

					@Override
					public void beforeTextChanged(View view, CharSequence s,
							int start, int count, int after) {

					}

					@Override
					public void onTextChanged(View view, CharSequence s,
							int start, int before, int count) {

						final String keywords = s.toString().trim();
						if ("".equals(keywords)) {
							if (mSearchEditText.isFocused()) {
								mSearchListView.setVisibility(View.GONE);
							}
						} else {
							if (mSearchEditText.isFocused()) {
								loadSearchListByKeywords(keywords);
							}
						}

					}
				});
	}

	@Override
	public void onClick(View view) {
		switch (view.getId()) {
		case R.id.indoor_search_category_btn_back:// 分类搜索返回按钮
			finish(null);
			break;

		case R.id.indoor_search_category_textview:// 点击顶部搜索TextView

			mSearchResultView.setVisibility(View.VISIBLE);
			mSearchListView.setVisibility(View.GONE);
			showSoftInput();

			break;

		case R.id.indoor_search_result_btn_back:// 搜索结果列表返回按钮

			mSearchEditText.setText("");
			IndoorUtility.hideInputMethod(mContext, mSearchEditText);
			mSearchResultView.setVisibility(View.GONE);
			mSearchResultTips.setVisibility(View.GONE);

			break;

		case R.id.indoor_search_edittext_clear_btn:// EditText清空按钮
			mSearchEditText.setText("");
			mSearchClearBtn.setVisibility(View.GONE);

			break;
		}
	}

	@Override
	public boolean onTouch(View view, MotionEvent event) {
		switch (view.getId()) {
		case R.id.indoor_search_result_list:

			if (event.getAction() == MotionEvent.ACTION_DOWN) {
				IndoorUtility.hideInputMethod(mContext, view);
			}

			return false;
		}

		return false;
	}
	@Override
	public boolean onBackPressed() {
		// getMapInterface().onDestroy();
		// manager.free();

		// }
		// @Override
		// public boolean onKeyDown(int keyCode, KeyEvent event) {
		// if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0)
		// {
		if (mSearchResultView.getVisibility() == View.VISIBLE) {
			if (mListViewAdapter != null) {
				mListViewAdapter.clearData();
			}

			mSearchEditText.setText("");
			IndoorUtility.hideInputMethod(mContext, mSearchEditText);
			mSearchResultView.setVisibility(View.GONE);
			mSearchResultTips.setVisibility(View.GONE);
			return true;
		}
		// else {
		// finish(null);
		// }
		// }
		// return super.onKeyDown(keyCode, event);
		return super.onBackPressed();
	}
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}
//	@Override
//	protected void onDestroy() {
//		super.onDestroy();
//
//		this.destroySearchResource();
//	}

	private void destroySearchResource() {
		if (mListViewAdapter != null) {
			mListViewAdapter.clearData();
		}
	}

	private void dismissLoadingDialog() {
		if (null != mLoadingDialog && mLoadingDialog.isShowing()) {
			mLoadingDialog.dismiss();
		}
	}

}

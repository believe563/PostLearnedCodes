package com.amap.indoor3d.demo;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.graphics.RectF;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.app.Fragment;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.amap.indoor3d.demo.model.PoiInfo;
import com.amap.indoor3d.demo.pathsearch.PathFragment;
import com.amap.indoor3d.demo.view.IndoorFloorView;
import com.gaode.indoormap.Listener.UserActionListener;
import com.gaode.indoormap.manager.IndoorDataListener;
import com.gaode.indoormap.manager.IndoorDataManager;
import com.gaode.indoormap.mapview.FloorInfo;
import com.gaode.indoormap.mapview.IndoorCompassWidget;
import com.gaode.indoormap.mapview.IndoorScaleWidget;
import com.gaode.indoormap.mapview.PoiMapCell;
import com.gaode.indoormap.mapview.PointD;
import com.gaode.indoormap.mapview.TextMapCell;
import com.gaode.indoormap.model.IndoorBuilding;
import com.gaode.indoormap.model.MallData;
import com.gaode.indoormap.model.RoutePathData;
import com.gaode.indoormap.model.RoutePathFloor;
import com.gaode.indoormap.searchengine.IndoorSearchManager;
import com.gaode.indoormap.util.LogHelper;
import com.gaode.indoormap.util.Utils;
import com.gaode.indoormap.widget.IntervalOnclickListener;
import com.taobao.mteam.blelocater.LocaterLocationNotify;
import com.taobao.mteam.blelocater.service.LocationData;
import com.taobao.png.R;

public class MainFragment extends MapBaseFragment implements OnClickListener,
		LocaterLocationNotify, IndoorDataListener {
	private final static int REQUEST_CODE_SEARCH = 1001;
	private TextView mTitleText;
	private PoiMapCell mSingleSnapPoi;
	private IndoorCompassWidget mCompassWidget;
	private Button mBtnGoHere;
	private TextView mTextPoi, text_poi_detail;
	private IndoorScaleWidget mIndoorScale;
	public static IndoorDataManager mIndoorManager;
	private final static String TAG = MainFragment.class.getSimpleName();
	private final static int COLOR_PRECISION = 0x330000FF;
	private final String indoorPath = PngMainActivity.indoorPath;
	private IndoorSearchManager searchManager = new IndoorSearchManager();
	private ArrayList<FloorInfo> flist = new ArrayList<FloorInfo>();
	private FloorInfo currentFloor;
	private AutoCompleteTextView et_input;
	// 当前位置
	private final int userFloorID = 1;
	private final double userX = 116.51860061083984;
	private final double userY = 39.924210059277344;
	public MainFragment(AliMapContext context, BackListener back) {
		super(context, null);
	}

	public MainFragment() {
		super(new AliMapContext(), null);
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	public static String getTime() {
		Calendar calendar = Calendar.getInstance();
		String created = calendar.get(Calendar.MINUTE) + ":"
				+ calendar.get(Calendar.SECOND) + " "
				+ calendar.get(Calendar.MILLISECOND) + " ";
		Log.e("msg", created);
		return created;
	}

	private void Init() {
		if ("请输入您申请的Key".equals(Utils.getKey(getActivity()))) {
			AlertDialog.Builder builder = new Builder(getActivity());
			builder.setMessage("请输入您申请的Key,并修改网站SHA1对应的编码");
			builder.setTitle("提示");
			builder.setPositiveButton("确认",
					new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which) {
							dialog.dismiss();
							getActivity().finish();
						}
					});
			// builder.setNegativeButton("取消", new
			// DialogInterface.OnClickListener() {
			// @Override
			// public void onClick(DialogInterface dialog, int which) {
			// dialog.dismiss();
			// }
			// });
			builder.create().show();
			return;
		}
		
		
		getMapInterface().setPrecisionRange(3, COLOR_PRECISION);
		mTitleText.setText("正在下载中");
		MallData data = new MallData(getAliMapContext().getPID(),
				getAliMapContext().getName());

		mIndoorManager = IndoorDataManager.CreateDataManager(data);
		mIndoorManager.setIndoorFolderPath("/mnt/sdcard/haha/");
		String path = mIndoorManager.getIndoorFolderPath();
		mIndoorManager.addIndoorDataListener(new IndoorDataListener() {
			@Override
			public void loadingStart() {

			}

			@Override
			public void loadingEnd(int errorCode, IndoorBuilding mIndoorBuilding) {
			}

			@Override
			public void loadingError(final int errorCode, final String msg) {
				Handler handler = new Handler(Looper.getMainLooper());
				handler.post(new Runnable() {
					@Override
					public void run() {
						Toast.makeText(getActivity(), msg, Toast.LENGTH_LONG)
								.show();
					}
				});
			}
		});
		getMapInterface().setMapDataListener(this);
		getMapInterface().setDataManager(mIndoorManager);
		mIndoorManager.clearCurrentCache();
		mIndoorManager.requestIndoorData(getActivity(), false);
		setMapData(mIndoorManager);
	}

	@Override
	public void onResume() {
		super.onResume();
		getAliMapContext().addLocaterLocationNotify(this);
		RoutePathData routePathData = getMapInterface().getRoutePathData();
		loadRoutePaths(routePathData);
	}

	@Override
	public void onPause() {
		super.onPause();
		getAliMapContext().removeLocaterLocationNotify(this);
	}

	@Override
	public void onFragmentBackResult(Bundle bundle, int requestCode,
			Fragment from) {
		getMapInterface().setOnUserActionListener(mUserActionListener);
		if (bundle != null) {
			if (requestCode == REQUEST_CODE_SEARCH) {
				String type = bundle.getString(IndoorSearchActivity.KEY_TYPE,
						"");
				if (IndoorSearchActivity.KEY_TYPE_PUB.equals(type)) {
					HashMap<String, Object> itemMap = (HashMap<String, Object>) bundle
							.getSerializable(IndoorSearchActivity.KEY_REQUEST);
					if (itemMap != null) {

					}
					hideTips();
				}
			}
		}

	}

	private View mView, bottomviewdetail;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container) {

		mView = inflater.inflate(R.layout.aliglmap_layout_fmain, null);
		mCompassWidget = (IndoorCompassWidget) mView
				.findViewById(R.id.indoor_compass_widget);
		bottomviewdetail = (View) mView.findViewById(R.id.bottomviewdetail);
		// mCompassWidget = (IndoorCompassWidget) mView
		// .findViewById(R.id.indoor_compass_widget);
		et_input = (AutoCompleteTextView) mView.findViewById(R.id.et_input);
		et_input.setOnClickListener(this);
		mCompassWidget.setIndoorCompassResource(R.drawable.indoor_compass_icon);
		mCompassWidget.setOnClickListener(this);
		mCompassWidget.setMapView(getAliMapContext().getMapInterface());
		mTitleText = (TextView) mView.findViewById(R.id.title);
		mTextPoi = (TextView) mView.findViewById(R.id.text_poi);
		text_poi_detail = (TextView) mView.findViewById(R.id.text_poi_detail);
		mBtnGoHere = (Button) mView.findViewById(R.id.btn_gohere);
		mView.findViewById(R.id.btn_log_selector).setOnClickListener(this);
		IndoorFloorView indoor_switchfloor_view = (IndoorFloorView) mView
				.findViewById(R.id.indoor_switchfloor_view);
		indoor_switchfloor_view.setVisibility(View.INVISIBLE);
		indoor_switchfloor_view.setIndoorView(getMapInterface());
		mBtnGoHere.setOnClickListener(this);
		mIndoorScale = (IndoorScaleWidget) mView
				.findViewById(R.id.indoor_scale_widget);
		mIndoorScale.setMapView(getAliMapContext().getMapInterface());

		mView.findViewById(R.id.btn_zoomout).setOnClickListener(this);
		mView.findViewById(R.id.btn_zoomin).setOnClickListener(this);
		mView.findViewById(R.id.btn_fixpos).setOnClickListener(this);

		getMapInterface().setOnUserActionListener(mUserActionListener);

		Init();
		initRoutePagerView();
		return mView;
	}

	private LayoutInflater mInflater;
	private RelativeLayout mRoutePathLayout;
	private ImageView mOnFootLeftBtn, mOnFooRightBtn;

	/** ==========================室内地图路线规划========================== */
	/**
	 * @Title: initRoutePlanView
	 * @Description: 初始化路线规划底部路段切换视图
	 */
	private void initRoutePagerView() {
		mInflater = getActivity().getLayoutInflater();
		mRoutePathLayout = (RelativeLayout) mView
				.findViewById(R.id.indoor_route_switch_layout);

		mOnFootLeftBtn = (ImageView) mView
				.findViewById(R.id.indoor_routeplan_browser_left_btn);
		mOnFootLeftBtn.setOnClickListener(new IntervalOnclickListener(
				new Runnable() {
					@Override
					public void run() {
						mHorizontalPager.setCurrentItem(mViewPagerIndex - 1,
								true);
					}
				}, 350));

		mOnFooRightBtn = (ImageView) mView
				.findViewById(R.id.indoor_routeplan_browser_right_btn);
		mOnFooRightBtn.setOnClickListener(new IntervalOnclickListener(
				new Runnable() {
					@Override
					public void run() {
						mHorizontalPager.setCurrentItem(mViewPagerIndex + 1,
								true);
					}
				}, 350));

		mHorizontalPager = (ViewPager) mView
				.findViewById(R.id.indoor_routeplan_horizontal_pager);
		mHorizontalPager.setOnPageChangeListener(new OnPageChangeListener() {
			@Override
			public void onPageSelected(int index) {
				showCurrentRoutePath(index);
			}

			@Override
			public void onPageScrolled(int arg0, float arg1, int arg2) {

			}

			@Override
			public void onPageScrollStateChanged(int arg0) {

			}
		});
	}

	UserActionListener mUserActionListener = new UserActionListener() {
		@Override
		public void onSingleTapUp(PointD point, int floorNum,
				List<PoiMapCell> poiList) {
			Log.v("wmh", "onSingleTapUp x=" + point.x + ",y=" + point.y);
			if (mRoutePathLayout.getVisibility() == View.VISIBLE) {
				return;
			}
			final PoiMapCell poiCell = poiList.get(0);
			if (poiCell == null) {
				return;
			}
			clearSingleSnapPoi();
			getMapInterface().clearMarkers();
			mSingleSnapPoi = poiCell;

			poiCell.setClickable(true);
			poiCell.setGravity(PoiMapCell.BOTTOM_CENTER);
			poiCell.setResId(R.drawable.indoor_bubble_blue);

			addMarker(poiCell);
		}

		@Override
		public void onLongPressed(PointD point, int floorNum,
				List<PoiMapCell> poiList) {
			Log.v("wmh", "onLongPressed x=" + point.x + ",y=" + point.y);
		}

		@Override
		public void onClick(List<PoiMapCell> makers) {
			if (mRoutePathLayout.getVisibility() == View.VISIBLE) {
				return;
			}
			for (PoiMapCell poiCell : makers) {
				Log.v("wmh",
						"onClick x=" + poiCell.getX() + ",y=" + poiCell.getY());
				if (mSingleSnapPoi == poiCell) {
					getMapInterface().removeMarker(poiCell);
					hideTips();
				}
				// else{
				// showTips(poiCell);
				// }
			}
			// Toast.makeText(getActivity(), "onMarkClick", Toast.LENGTH_LONG)
			// .show();
		}
	};
	private int mViewPagerIndex = 0;
	// 起终点类型
	public static final byte START = 0x39;
	public static final byte END = 0x40;

	/**
	 * @Title: showCurrentPage
	 * @Description: 室内路线规划底部左右滑动切换查看路线:指路＋分段路线
	 * @param @param index 设定文件
	 * @return void 返回类型
	 * @throws
	 */
	private void showCurrentRoutePath(int index) {
		mViewPagerIndex = index;
		Integer nextFloor = null;
		String nextFloorName = "";
		getMapInterface().clearMarkers();
		RoutePathFloor curFloorRoute = mRoutePathFloorList.get(index);
		if (curFloorRoute != null) {
			int floorID = Integer.valueOf(curFloorRoute.mFloorNumber);
			if (floorID != getMapInterface().getFloorID()) {
				getMapInterface().loadMapFloor(floorID);
			}
		} else {
			Toast.makeText(getActivity(), "对象不存在!", Toast.LENGTH_LONG).show();
		}
		byte startAction = -1;
		byte endAction = Byte.decode(curFloorRoute.mAction).byteValue();
		if (curFloorRoute.mPathPointLst.size() <= 1) {
			return;
		}
		PointD start = new PointD(curFloorRoute.mPathPointLst.get(0));
		PointD end = new PointD(
				curFloorRoute.mPathPointLst.get(curFloorRoute.mPathPointLst
						.size() - 1));
		start.x = start.x / 3600f;
		start.y = start.y / 3600f;
		end.x = end.x / 3600f;
		end.y = end.y / 3600f;
		// ScreenPointInfo
		// startMapInfo=getMapInterface().graphPoint2POI(start.x,start.y);
		// ScreenPointInfo
		// endMapInfo=getMapInterface().graphPoint2POI(end.x,end.y);

		if (index == 0) {// 指路界面：显示最后一段路线
			mOnFootLeftBtn.setVisibility(View.GONE);
			mOnFooRightBtn.setVisibility(View.GONE);
			startAction = START;
		} else {// 分段显示路线
			if (index == 1) {
				mOnFootLeftBtn.setVisibility(View.GONE);
			} else {
				mOnFootLeftBtn.setVisibility(View.VISIBLE);
			}

			mOnFooRightBtn.setVisibility(View.VISIBLE);
			if (mViewPagerIndex == mRoutePathFloorList.size() - 1) {
				mOnFooRightBtn.setVisibility(View.INVISIBLE);
			}

			int nextNum = index + 1;
			if (nextNum < mRoutePathFloorList.size()) {
				RoutePathFloor nextNaviInfo = mRoutePathFloorList.get(nextNum);
				if (null != nextNaviInfo) {
					if (!TextUtils.isEmpty(nextNaviInfo.mFloorNumber)) {
						nextFloor = Integer.valueOf(nextNaviInfo.mFloorNumber);
						nextFloorName = nextNaviInfo.mFloorName;
					}
				}
			}

			if (index == 1) {
				startAction = START;
			} else if (index <= mRoutePathFloorList.size() - 1) {
				RoutePathFloor startNaviInfo = mRoutePathFloorList
						.get(index - 1);
				startAction = Byte.decode(startNaviInfo.mAction).byteValue();

			}
		}

		if (start != null) {
			PoiMapCell poiCell = new PoiMapCell(start.x, start.y, "start");
			poiCell.setClickable(true);
			poiCell.setGravity(PoiMapCell.CENTER);
			int res = getTipsRes(startAction);
			if (res != 0) {
				poiCell.setResId(res);
			} else {
				Toast.makeText(
						getActivity(),
						"Action is not res:curFloorRoute.mAction="
								+ curFloorRoute.mAction, Toast.LENGTH_LONG)
						.show();
			}
			getMapInterface().addMarker(poiCell);

			// RectF textRect = new RectF();
			// textRect.left = 0f;
			// textRect.top = 0.5f;
			// textRect.right = 1.0f;
			// textRect.bottom = 0.3571f;
			// TextMapCell mapCell = new TextMapCell(textRect, 0xffffffff, 25);
			// mapCell.setX(start.x);
			// mapCell.setY(start.y);
			// mapCell.setClickable(true);
			// mapCell.setName(curFloorRoute.startTipsName(startAction));
			// mapCell.setGravity(PoiMapCell.BOTTOM_CENTER);
			// mapCell.setResId(R.drawable.indoor_bubble_train);
			// getMapInterface().addMarker(mapCell);
		}
		if (end != null) {
			// PoiMapCell poiCell = endMapInfo.getPoiMapCells().get(0);
			PoiMapCell poiCell = new PoiMapCell(end.x, end.y, "end");
			poiCell.setClickable(true);
			poiCell.setGravity(PoiMapCell.CENTER);
			int res = getTipsRes(Byte.decode(curFloorRoute.mAction)
					.byteValue());
			if (res != 0) {
				poiCell.setResId(res);
			} else {
				Toast.makeText(
						getActivity(),
						"Action is not res:curFloorRoute.mAction="
								+ curFloorRoute.mAction, Toast.LENGTH_LONG)
						.show();
				// poiCell.setResId(R.drawable.indoor_end);
			}
			getMapInterface().addMarker(poiCell);
			String endTipsName = curFloorRoute.endTipsName(
					Byte.decode(curFloorRoute.mAction).byteValue(),
					nextFloorName);
			if (!TextUtils.isEmpty(endTipsName)) {
				RectF textRect = new RectF();
				textRect.left = 0f;
				textRect.top = 0.5f;
				textRect.right = 1.0f;
				textRect.bottom = 0.3571f;
				TextMapCell mapCell = new TextMapCell(textRect, 0xffffffff, 25);
				mapCell.setX(end.x);
				mapCell.setY(end.y);
				mapCell.setClickable(true);
				mapCell.setName(endTipsName);
				mapCell.setGravity(PoiMapCell.BOTTOM_CENTER);
				mapCell.setResId(R.drawable.indoor_bubble_train);
				getMapInterface().addMarker(mapCell);
			}
		}
		// 计算中心点
		double x = (start.x - end.x) / 2f;
		double y = (start.y + end.y) / 2f;
		// getMapInterface().setPathData(curFloorRoute.mFloorNumber,
		// curFloorRoute.mPathPointLst);
		getMapInterface().setViewPortToLocation(start.x, start.y);
		getMapInterface().setScale(1f);
		getMapInterface().updateLoc(userX, userY, userFloorID);
		// 不在当前楼层，切换楼层
	}

	private ProgressDialog dialog;

	public void showTips(PoiMapCell poiCell) {
		mTextPoi.setText(poiCell.getName());
		text_poi_detail.setText(""
				+ getMapInterface().getFloorNameCode(poiCell.getFloorNo()));
		bottomviewdetail.setVisibility(View.VISIBLE);
	}

	public void hideTips() {
		bottomviewdetail.setVisibility(View.GONE);
	}

	public int addMarker(PoiMapCell poiCell) {
		showTips(poiCell);
		return getMapInterface().addMarker(poiCell);
	}

	@Override
	public void onStart() {
		getMapInterface().setOnUserActionListener(mUserActionListener);
		if (currentFloor != null) {
			getMapInterface().loadMapFloor(currentFloor.fl_index);
		}
		// getMapInterface().clearPaths();
		// getMapInterface().clearMarkers();
		// mRoutePathLayout.setVisibility(View.GONE);

		// mMapState=null;
		// if (mSingleSnapPoi != null) {
		// getMapInterface().addMarker(mSingleSnapPoi);
		// }
		super.onStart();
	}

	private void clearSingleSnapPoi() {
		if (mSingleSnapPoi != null) {
			getMapInterface().removeMarker(mSingleSnapPoi);
		}
	}

	float scale = 1;

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btn_zoomout:
			btnZoomOut();
			break;
		case R.id.btn_zoomin:
			btnZoomIn();
			break;
		case R.id.btn_fixpos:
			loadMylocation();
			break;
		case R.id.btn_gohere:
			btnGoHere();
			break;
		case R.id.indoor_compass_widget:// 指北针
			getMapInterface().resetMapOrientation();
			break;
		case R.id.btn_log_selector:// 显示Log
			// ShowLogDialog();
			break;
		case R.id.et_input:
			// 搜索界面
			if (mRoutePathLayout.getVisibility() != View.VISIBLE) {
				IndoorSearchActivity pathFragment = new IndoorSearchActivity(
						getAliMapContext(), this, this, null);
				showFragment(pathFragment, R.id.aliglmap_container,
						REQUEST_CODE_SEARCH, true);
			}
			break;
		}
	}

	/**
	 * 加载指定的位置
	 */
	private void loadMylocation() {
		getMapInterface().updateLoc(userX, userY, userFloorID);
	}

	private void btnGoHere() {
		PathFragment pathFragment = new PathFragment(getAliMapContext(), this,
				null);
		if (mSingleSnapPoi != null) {
			PoiInfo mInfoTo = new PoiInfo();
			mInfoTo.cell = mSingleSnapPoi;
			mInfoTo.floor = new FloorInfo("", "0", getMapInterface()
					.getFloorID());
			pathFragment.setPoiInfoFrom();
			pathFragment.setPoiInfoTo(mInfoTo);
		}
		showFragment(pathFragment, R.id.aliglmap_container, true);
	}

	public void btnZoomOut() {
		int result = getMapInterface().zoomOut();
		if (result == 2)
			Toast.makeText(getActivity(), "已经是最少比例", Toast.LENGTH_LONG).show();
	}

	public void btnZoomIn() {
		// float result = getMapInterface().setScale(2f);
		// Toast.makeText(getActivity(),
		// "zoomIn:" + result + ":" + getMapInterface().getScale(),
		// Toast.LENGTH_LONG).show();
		int result = getMapInterface().zoomIn();
		if (result == 2)
			Toast.makeText(getActivity(), "已经放大到最大", Toast.LENGTH_LONG).show();
	}

	private List<RoutePathFloor> mRoutePathFloorList;
	private ViewPager mHorizontalPager;

	/**
	 * @Title: loadRoutePaths
	 * @Description: 加载路线
	 */
	private void loadRoutePaths(RoutePathData routeData) {
		try {
			if (routeData == null) {
				return;
			}
			List<RoutePathFloor> tempRoutePathFloorList = routeData.mFullPath;
			if (null != tempRoutePathFloorList
					&& tempRoutePathFloorList.size() > 0) {
				int infoSize = tempRoutePathFloorList.size();
				if (null == mRoutePathFloorList)
					mRoutePathFloorList = new ArrayList<RoutePathFloor>();
				else
					mRoutePathFloorList.clear();

				if (infoSize == 1) {// 只有一段路
					mRoutePathFloorList.add(tempRoutePathFloorList.get(0));
				} else if (infoSize > 1) {// 有多段路
					mRoutePathFloorList.add(tempRoutePathFloorList.get(0));// 先加最后一段路
					for (int i = 0; i < infoSize; i++) {
						mRoutePathFloorList.add(tempRoutePathFloorList.get(i));
					}
				}
				mRoutePathLayout.setVisibility(View.VISIBLE);
				bottomviewdetail.setVisibility(View.GONE);
				// 总距离
				final int countDistance = routeData.mDistance;
				mHorizontalPager.setAdapter(new PagerAdapter() {
					@Override
					public boolean isViewFromObject(View arg0, Object arg1) {
						return arg0 == arg1;
					}

					@Override
					public int getCount() {
						return mRoutePathFloorList.size();
					}

					@Override
					public Object instantiateItem(ViewGroup container,
							int position) {
						RoutePathFloor routeFloor = mRoutePathFloorList
								.get(position);
						View view = null;
						if (position == 0) {// 指路
							view = mInflater.inflate(
									R.layout.indoor_viewpager_first_item, null);

							TextView timeTxt = (TextView) view
									.findViewById(R.id.indoor_route_time);

							TextView distanceTxt = (TextView) view
									.findViewById(R.id.indoor_route_distance);

							// 指路按钮
							Button btnRouteWay = (Button) view
									.findViewById(R.id.indoor_btn_route_way);

							btnRouteWay
									.setOnClickListener(new OnClickListener() {
										@Override
										public void onClick(View view) {
											// 起始路线
											mHorizontalPager.setCurrentItem(1);
										}
									});

							int s = (int) (countDistance * 1.2 / 60);
							if (s == 0) {
								s = 1;
							}
							timeTxt.setText("大约" + s + "分钟");
							distanceTxt.setText(countDistance + "米");
							if (getCount() == 1) {
								btnRouteWay.setVisibility(View.GONE);
							}
						} else {// 分段
							view = mInflater.inflate(
									R.layout.indoor_viewpager_item, null);
							TextView naviDes = (TextView) view
									.findViewById(R.id.indoor_foot_browser_main_des);
							naviDes.setText("步行" + routeFloor.mSegDistance
									+ "米");
						}

						container.addView(view);

						return view;
					}

					@Override
					public void destroyItem(ViewGroup container, int position,
							Object object) {
						container.removeView((View) object);
					}
				});
				mHorizontalPager.setCurrentItem(0);
				showCurrentRoutePath(0);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public boolean onBackPressed() {
		if (mRoutePathLayout.getVisibility() == View.VISIBLE) {
			mRoutePathLayout.setVisibility(View.GONE);
			bottomviewdetail.setVisibility(View.GONE);

			getMapInterface().setPathData(null);
			getMapInterface().clearPaths();
			getMapInterface().clearMarkers();
			getMapInterface().updateLoc(userX, userY, userFloorID);
			mRoutePathLayout.setVisibility(View.GONE);
			return true;
		}
		return super.onBackPressed();
	}

	@Override
	public void onLocationChanged(LocationData locationData) {
		// 定位
		if (currentFloor != null && currentFloor.fl_index == locationData.layer) {
			double x = locationData.lon;
			double y = locationData.lat;
			getMapInterface().updateLoc(x, y, currentFloor.fl_index);
			getMapInterface().setViewPortToLocation(locationData.lon,
					locationData.lat);
		}
	}

	@Override
	public void loadingStart() {
		showProgressDialog();
	}

	@Override
	public void loadingEnd(int code, IndoorBuilding mIndoorBuilding) {
		// TODO Auto-generated method stub
		dismissProgressDialog();
		Handler handler = new Handler(Looper.getMainLooper());
		handler.postAtTime(new Runnable() {
			@Override
			public void run() {
				mTitleText.setText(getAliMapContext().getName());
				mTextPoi.setText("");
				float scale = getMapInterface().setScale(0.0f);

				getMapInterface().updateLoc(userX, userY, userFloorID);
				Log.v("wmh", "MainFragment.loadingEnd scale=" + scale);
				PointD point = getMapInterface().getCenterToLocationXY();
				if (point != null) {
					Log.v("wmh", "MainFragment.loadingEnd x=" + point.x + ",y="
							+ point.y);
				} else {
					Log.v("wmh", "MainFragment.loadingEnd point is NULL");
				}
			}
		}, 2000);
	}

	@Override
	public void loadingError(final int errorCode, final String msg) {
		dismissProgressDialog();
	}

	private void showProgressDialog() {
		LogHelper.print(TAG, "正在下载数据...");
	}

	private void dismissProgressDialog() {
		LogHelper.print(TAG, "下载完成...");
	}

	public int getTipsRes(int startType) {
		int resId = 0;
		switch (startType) {
		case 0x00: {
			// resId = "无基本导航动作";
			resId = R.drawable.indoor_bubble_enter_building;
			break;
		}
		case 0x01: {
			// resId = "进入建筑物";
			resId = R.drawable.indoor_bubble_enter_building;
			break;
		}

		case 0x02: {
			// resId = "离开建筑物";
			resId = R.drawable.indoor_bubble_leave_building;
			break;
		}

		case 0x41:
		case 0x42: {
			// resId = "进门";
			resId = R.drawable.indoor_passageway;
			break;
		}

		case 0x03:
		case 0x43: {
			// resId = "出电梯";
			resId = R.drawable.indoor_lift;
			break;
		}

		case 0x04:
		case 0x44: {
			// resId = "出楼梯";
			resId = R.drawable.indoor_stair;
			break;
		}

		case 0x05:
		case 0x45: {
			// resId = "出扶梯";
			resId = R.drawable.indoor_escalator;
			break;
		}
		case 0x06: {
			// resId = "终点";
			resId = R.drawable.indoor_end;
			break;
		}
		case 0x39: {
			// resId = "起点";
			resId = R.drawable.indoor_start;
			break;
		}
		}
		return resId;
	}
}

/** Automatically generated file. DO NOT MODIFY */
package com.taobao.png;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
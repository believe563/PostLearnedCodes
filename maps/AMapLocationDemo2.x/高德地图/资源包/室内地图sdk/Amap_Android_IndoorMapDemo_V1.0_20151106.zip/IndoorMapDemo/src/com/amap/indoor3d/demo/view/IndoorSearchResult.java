package com.amap.indoor3d.demo.view;

import java.io.Serializable;

/**
 * @ClassName: IndoorSearchResult
 * @Description: 室内搜索实体类
 * @author ruimin.cao
 * @date 2014-7-15
 * @version 1.0
 */
public class IndoorSearchResult implements Serializable {
	private static final long serialVersionUID = 1L;

	public String mFindId;
	
	public String mNaviId;
	
	public String mBrandId;

	public String mName;

	public String mAddress;

	public int mFloor;
	
	public String mSndtType;
	
	// 是否从搜索服务设施返回
	public boolean isFromSearchPubBack = false;
}

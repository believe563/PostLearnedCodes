package com.amap.indoor3d.demo.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.gaode.indoormap.model.FloorData;
import com.gaode.indoormap.model.MallData;

public class MapData {
	//MallInfo
	public MallData currentMall;
	//Mall FloorData
	private List<FloorData> floorList= new ArrayList<FloorData>();
	public void setFloorList(List<FloorData> floorList){
		this.floorList=floorList;
	}
	public List<FloorData> getFloorList(){
		return floorList;
	}
	public void addFloorData(FloorData floorData){
		this.floorList.add(floorData);
	}
	public FloorData getFloorData(int pos){
		return this.floorList.get(pos);
	}	
	//查询列表
	public HashMap<Integer, FloorData> floorMap;
	//当前楼层信息
	public FloorData currentFloor;
}

package com.amap.indoor3d.demo.list;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.amap.indoor3d.demo.PngMainActivity;
import com.amap.indoor3d.demo.list.IndoorBuildingListRequest.IndoorBuildingListCallBack;
import com.gaode.indoormap.model.IndoorBuilding;
import com.taobao.png.R;

/**
 * @ClassName: IndoorBuildingListActivity
 * @Description: 室内搜索列表
 * @author ruimin.cao
 * @date 2014-6-27
 * @version 1.0
 * 
 */
public class IndoorListActivity extends Activity implements
		OnClickListener, IndoorBuildingListCallBack {
	private ProgressDialog mProgressDialog;
	private ImageButton mIndoorBtnBack;
	private Button mSearchBtn;
	private TextView mIndoorBuildingCount;
	private EditText mInputKeywords;
	private ListView mIndoorBuildingList;
	private ListAdapter mListAdapter;

	private List<IndoorBuilding> mBuildingList = null;
	public static final String BUILDINGPOIID = "BUILDING_POIID";
	public static final String BUILDINGNAME = "BUILDING_NAME";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_indoorlist);
		final String url = "http://10.61.206.212:8080/v3/indoor/indoormaps?from=miaojie&key=380fc1f4ee0ec7b9dd1251c9397b9600&poiid=B023B173VP&servicetype=sdk&version=0&scode=5833456388a870076470f34cadf79f34&ts=1441967916933000";
		
//		final HttpRequester request = new HttpRequester();     
//		HttpRespons hr= null;
//		new Thread(new Runnable() {
//			
//			@Override
//			public void run() {
//				// TODO Auto-generated method stub
//				try {
//					HttpRespons hr = request.sendGet(url);
//				} catch (Exception e) {
//					return;
//				}		
//			}
//		}).start();
		
//		mIndoorBtnBack = (ImageButton) findViewById(R.id.indoor_list_btn_back);
//		mIndoorBtnBack.setOnClickListener(this);

		mInputKeywords = (EditText) findViewById(R.id.indoor_building_keywords);
		
		findViewById(R.id.indoor_btn_refresh).setOnClickListener(this);
		mSearchBtn = (Button) findViewById(R.id.indoor_list_btn_search);
		mSearchBtn.setOnClickListener(clickListener);
		
		mIndoorBuildingCount = (TextView) findViewById(R.id.indoor_building_count);
		mIndoorBuildingCount.setTextColor(Color.RED);

		mIndoorBuildingList = (ListView) findViewById(R.id.indoor_list_result);
		mIndoorBuildingList.setOnItemClickListener(indoorListListener);

		mListAdapter = new ListAdapter();
		mIndoorBuildingList.setAdapter(mListAdapter);

		requestIndoorListData();
	}
	
	private void requestIndoorListData(){
//		if(mBuildingList == null){
			mProgressDialog = ProgressDialog.show(IndoorListActivity.this, null, "正在加载数据，请稍候...");
			mProgressDialog.setCancelable(true);
			
			IndoorBuildingListRequest buildingListRequest = new IndoorBuildingListRequest("GET");
			buildingListRequest.setRequestUrl( "http://203.130.47.12:80/");
//			buildingListRequest.setRequestUrl( IndoorServer.getIndoorMapRequestURL());
//			private static final String mIndoorMapRequestURL = "http://indoor.amap.com/";//"http://203.130.47.12:80/"; //"http://indoor.amap.com/";
			buildingListRequest.setBuildingListCallBack(this);
			buildingListRequest.setIndoorListParams();
			buildingListRequest.setParamCompress(true);
			buildingListRequest.startRequestTask();
//		} else {
//			mIndoorBuildingCount.setText("室内数量:" + mBuildingList.size() + "个");
//			mListAdapter.setIndoorBuildingList(mBuildingList);
//		}
	}

	private OnItemClickListener indoorListListener = new OnItemClickListener() {
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
			IndoorBuilding building = (IndoorBuilding) mListAdapter.getItem(position);
			if (building != null && !TextUtils.isEmpty(building.getbuilingPoiid())) {
//				OnLineIndoorActivity
//				Intent intent = new Intent(getBaseContext(), OnLineIndoorActivity.class);
				Intent intent = new Intent(getBaseContext(), PngMainActivity.class);
				intent.putExtra(BUILDINGPOIID, building.getbuilingPoiid());
				intent.putExtra(BUILDINGNAME, building.getBuildingName());
				
//				IndoorDataManager mDataManager = IndoorDataManager.getInstance();
//				mDataManager.setHandler(new Handler());
//				mDataManager.requestIndoorData(IndoorListActivity.this, building.mStrAutonaviPID, 1);
//				try {
//					Thread.sleep(3000);
//				} catch (InterruptedException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
				startActivity(intent);
			} else {
				Toast.makeText(getApplicationContext(), "该建筑物poiid为空", Toast.LENGTH_SHORT).show();
			}
		}
	};

	private OnClickListener clickListener = new OnClickListener() {
		@Override
		public void onClick(View v) {
			if (v.equals(mSearchBtn) && mBuildingList != null) {
				String keywords = mInputKeywords.getText().toString().trim();
				if (keywords.length() > 0) {
					ArrayList<IndoorBuilding> searchBuildings = new ArrayList<IndoorBuilding>();
					for (int i = 0; i < mBuildingList.size(); i++) {
						IndoorBuilding building = mBuildingList.get(i);
						if (building.getBuildingName().contains(keywords) || building.getBuildingName().contains(keywords)) {
							searchBuildings.add(building);
						}
					}

					if (searchBuildings.size() > 0) {
						mListAdapter.setIndoorBuildingList(searchBuildings);
						mInputKeywords.setText("共：" + searchBuildings.size()
								+ "个");
						Toast.makeText(getApplication(),
								"共找到" + searchBuildings.size() + "栋包含该关键词的建筑物",
								Toast.LENGTH_SHORT).show();
					} else {
						Toast.makeText(getApplication(), "未找到包含该关键词的建筑物",
								Toast.LENGTH_SHORT).show();
					}
				} else {
					mIndoorBuildingCount.setText("共：" + mBuildingList.size() + "个");
					mListAdapter.setIndoorBuildingList(mBuildingList);
				}
			}
		}
	};

	class ListAdapter extends BaseAdapter {
		List<IndoorBuilding> buildings = new ArrayList<IndoorBuilding>();

		public void setIndoorBuildingList(List<IndoorBuilding> buildingList) {
			if (buildingList != null) {
				this.buildings = buildingList;
			}

			this.notifyDataSetChanged();
		}

		@Override
		public int getCount() {
			return buildings.size();
		}

		@Override
		public IndoorBuilding getItem(int position) {
			return buildings.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			if (buildings.size() == 0)
				return null;

			View rootView = convertView;
			ViewHolder viewHolder = null;
			if (rootView == null) {
				viewHolder = new ViewHolder();
				viewHolder.linearLayout = new LinearLayout(parent.getContext());
				viewHolder.linearLayout.setPadding(15, 20, 10, 20);
				viewHolder.name = new TextView(parent.getContext());
				viewHolder.name.setTextSize(18);
				viewHolder.name.setTextColor(Color.BLACK);
				viewHolder.linearLayout.addView(viewHolder.name);
				rootView = viewHolder.linearLayout;
				rootView.setTag(viewHolder);
			} else {
				viewHolder = (ViewHolder) rootView.getTag();
			}

			IndoorBuilding building = buildings.get(position);
			if(null != building.getBuildingName() && !"".equals(building.getBuildingName())){
				viewHolder.name.setText(building.getBuildingName());
			}else{
				viewHolder.name.setText(building.getBuildingName());
			}

			return rootView;
		}

		class ViewHolder {
			LinearLayout linearLayout;
			TextView name;
		}
	}

	@Override
	public void onClick(View view) {
		switch (view.getId()) {
		case R.id.indoor_btn_refresh:
			requestIndoorListData();
			break;
		}
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			
			if(null != mProgressDialog && mProgressDialog.isShowing()){
				mProgressDialog.dismiss();
			}
			
			if(null != mBuildingList){
				mBuildingList.clear();
				mBuildingList = null;
			}
			
			finish();
			
			return true;
		}

		return super.onKeyDown(keyCode, event);
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
	}

	@Override
	public void onFinishParseBuildList(final List<IndoorBuilding> buildingList) {
		mSearchBtn.post(new Runnable(){
			@Override
			public void run() {
				if(null != mProgressDialog && mProgressDialog.isShowing()){
					mProgressDialog.dismiss();
				}
				
				if (null != buildingList && buildingList.size() > 0) {
					mBuildingList = buildingList;
					mIndoorBuildingCount.setText("室内数量:" + mBuildingList.size() + "个");
					mListAdapter.setIndoorBuildingList(mBuildingList);
				} else {
					Toast.makeText(IndoorListActivity.this, "数据访问失败",
							Toast.LENGTH_SHORT).show();
				}
			}
		});
	}

	@Override
	public void onRetErrorCode(int errorCode) {
		mSearchBtn.post(new Runnable() {
			@Override
			public void run() {
				if(null != mProgressDialog && mProgressDialog.isShowing()){
					mProgressDialog.dismiss();
				}
				Toast.makeText(IndoorListActivity.this, "数据访问失败",
						Toast.LENGTH_SHORT).show();
			}
		});
	}

}

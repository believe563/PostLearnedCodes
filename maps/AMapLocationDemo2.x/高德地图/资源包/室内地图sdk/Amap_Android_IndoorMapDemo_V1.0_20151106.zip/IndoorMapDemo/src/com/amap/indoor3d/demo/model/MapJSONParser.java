package com.amap.indoor3d.demo.model;
//package com.taobao.png.model;
//
//import java.util.ArrayList;
//import java.util.HashMap;
//
//import org.json.JSONArray;
//import org.json.JSONException;
//import org.json.JSONObject;
//
//import com.gaode.indoormap.mapcore.GraphPoint;
//import com.gaode.indoormap.mapview.PoiMapCell;
//import com.gaode.indoormap.model.FloorData;
//import com.taobao.png.AliMapContext;
//
//public class MapJSONParser {
////	public static MapData parseFloorData(String json) {
////		try {
////			JSONObject jsonObject = new JSONObject(json);
////			if (jsonObject.has("data")) {
////				MapData mapData = new MapData();
////				mapData.floorMap = new HashMap<Integer,FloorData>();
////				JSONObject data = jsonObject.getJSONObject("data");
////				if (data.has("building")) {
//////					JSONObject building = data.getJSONObject("building");
//////					mapData.bd_autonavi_pid = building
//////							.getString("bd_autonavi_pid");
////				}
////				if (data.has("floors")) {
////					JSONArray array = data.getJSONArray("floors");
////					for (int i = 0; i < array.length(); i++) {
////						FloorData f = new FloorData();
////						JSONObject obj = (JSONObject) array.get(i);
////						if (obj.has("fl_sourceid")) {
////							f.fl_sourceid = obj.getString("fl_sourceid");
////						}
////						if (obj.has("fl_namecode")) {
////							f.fl_namecode = obj.getString("fl_namecode");
////						}
////						if (obj.has("fl_index")) {
////							f.fl_index = obj.getInt("fl_index");
////						}
////						mapData.floorMap.put(f.fl_index, f);
////						mapData.addFloorData(f);
////					}
////					mapData.currentFloor = mapData.getFloorData(0);
////				}
////				return mapData;
////			}
////		} catch (JSONException e) {
////			e.printStackTrace();
////		}
////		return null;
////	}
//
//	public static void parseMapRouth(String jsonStr, PoiInfo from, PoiInfo to,AliMapContext context, ArrayList<PoiInfo> outList,HashMap<Integer,ArrayList<PoiInfo>> outPath) {
//		try {
//			JSONObject obj = new JSONObject(jsonStr);
//			if (obj.has("route")) {
//				JSONArray array = obj.getJSONArray("route");
//				if (array.length() > 0) {
//					JSONObject route0 = (JSONObject) array.get(0);
//					if (route0.has("path")) {
//						JSONObject paths = route0.getJSONObject("path");
//						if (paths.has("naviInfoList")) {
//							JSONArray navlist = paths
//									.getJSONArray("naviInfoList");
//							outList.add(from);
//							for (int i = 0; i < navlist.length(); i++) {
//								JSONObject listitem = (JSONObject) navlist
//										.get(i);
//								if (listitem.has("geometry")
//										&& listitem.has("floor")) {
//									FloorData floorData = new FloorData();
//									int floor = listitem.getInt("floor");
//									String fn = listitem.getString("fn");
//									floorData.fl_index = floor;
//									floorData.fl_namecode = fn;
//									JSONArray geometry = listitem
//											.getJSONArray("geometry");
//									ArrayList<PoiInfo> list = new ArrayList<PoiInfo>();
//									for (int j = 0; j < geometry.length(); j++) {
//										PoiInfo info = new PoiInfo();
//										info.cell = new PoiMapCell();
//										FloorData fl = context.getMapData().getCurrentIndoorBuilding().floorMap
//												.get(floorData.fl_index);
//										info.floor = fl!=null?fl:floorData;
//										JSONObject cell = (JSONObject) geometry
//												.get(j);
//										double x = cell.getDouble("x")*3600f;
//										double y = cell.getDouble("y")*3600f;
//										info.cell.setX(x);
//										info.cell.setY(y);
//										GraphPoint point = new GraphPoint();
//										point.longitude = x;
//										point.latitude = y;
//										point.layer = floor;
////										POIInfo p = SearchCore
////												.getPoint2NearestPOI(point);
//										if(!"".equals(fn)){
//											info.cell.setName(fn);//by wmh 缺少Name
//										}else{
//											info.cell.setName("i:"+i+"-j:"+j);
//										}
//										outList.add(info);
//										list.add(info);
//									}
//									outPath.put(floor, list);
//								}
//							}
//							outList.add(to);
//						}
//					}
//				}
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
//}

package com.amap.indoor3d.demo;

import android.app.Application;

public class MapApplication extends Application{
	
//	public static Application app;

	@Override
	public void onCreate() {
		super.onCreate();
//		app = this;
//		MapConfig.init(getApplicationContext());
//		try {
//			InputStream input = getAssets().open("alimap.zip");
//			String path = Environment.getExternalStorageDirectory().getAbsolutePath();
//			DataUnzip.unZip(input, path);
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
	}

}

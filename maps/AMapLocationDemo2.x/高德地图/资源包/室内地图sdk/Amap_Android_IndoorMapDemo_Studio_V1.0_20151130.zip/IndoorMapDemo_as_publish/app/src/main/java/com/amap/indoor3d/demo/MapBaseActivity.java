package com.amap.indoor3d.demo;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.view.KeyEvent;

import com.taobao.png.R;

public class MapBaseActivity extends FragmentActivity{
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}
	
	protected void showFragment(Fragment fragment,int containerId,boolean backstack){
		showFragment(fragment, 0, 0, 0, 0, containerId,backstack);
	}
	
	protected void showFragment(Fragment fragment,int pageEnterAnim,int pageExitAnim,int popEnter,int popEixt,int containerId,boolean backstack){
		showFragment(fragment, pageEnterAnim, pageExitAnim, popEnter,popEixt,backstack, containerId);
	}
	 
	private void showFragment(Fragment fragment,int pageEnterAnim,int pageExitAnim,int popEnter,int popEixt,boolean backstack,int containerId){
	        FragmentTransaction transcation = getSupportFragmentManager().beginTransaction();
	        transcation.setCustomAnimations(pageEnterAnim, pageExitAnim,popEnter,popEixt);
	        transcation.replace(containerId,fragment);
	        if(backstack){
	            transcation.addToBackStack(null);
	        }
	        transcation.commit();
	}
	
	@Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
    	if (keyCode == KeyEvent.KEYCODE_BACK
                && event.getAction() == KeyEvent.ACTION_DOWN) {
            MapBaseFragment fragment =  (MapBaseFragment)getSupportFragmentManager().findFragmentById(R.id.aliglmap_container);
            if(fragment!=null){
                if(fragment.onBackPressed()){
                	return true;
                }
            }   
        }
    	return super.onKeyDown(keyCode, event);
    }
	
}

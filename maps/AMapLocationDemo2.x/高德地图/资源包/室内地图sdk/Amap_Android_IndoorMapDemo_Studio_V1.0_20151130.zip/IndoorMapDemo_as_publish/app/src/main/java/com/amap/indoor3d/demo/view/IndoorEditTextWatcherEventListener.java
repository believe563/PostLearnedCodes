package com.amap.indoor3d.demo.view;

import android.text.Editable;
import android.view.View;

/**
 * @ClassName: IndoorEditTextWatcherEventListener
 * @Description: 室内地图自定义EditText接口
 * @author ruimin.cao
 * @date 2014-7-4
 * @version 1.0
 */
public interface IndoorEditTextWatcherEventListener {

	public void afterTextChanged(View view, Editable s);

	public void beforeTextChanged(View view, CharSequence s, int start, int count, int after);

	public void onTextChanged(View view, CharSequence s, int start, int before, int count);
}

package com.amap.indoor3d.demo.view;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.View;
import android.widget.EditText;

/**
 * @ClassName: IndoorEditText
 * @Description: 室内搜索自定义EditText
 * @author ruimin.cao
 * @date 2014-7-4
 * @version 1.0
 */
public class IndoorEditText extends EditText {
	private IndoorEditTextWatcherEventListener mTextWatcherEventListener = null;

	public void setTextWatcherEventListener(IndoorEditTextWatcherEventListener listener) {
		mTextWatcherEventListener = listener;
	}

	public IndoorEditText(Context context) {
		this(context, null);
	}

	public IndoorEditText(Context context, AttributeSet attributeSet) {
		this(context, attributeSet, android.R.attr.autoCompleteTextViewStyle);
	}

	public IndoorEditText(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
		super(paramContext, paramAttributeSet, paramInt);
		
		setFocusable(true);
		addTextChangedListener(new AutoWatcher(this));
	}

	private class AutoWatcher implements TextWatcher {
		private View view;

		public AutoWatcher(View view) {
			this.view = view;
		}

		@Override
		public void afterTextChanged(Editable s) {
			if (mTextWatcherEventListener != null) {
				mTextWatcherEventListener.afterTextChanged(view, s);
			}
		}

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
			if (mTextWatcherEventListener != null) {
				mTextWatcherEventListener.beforeTextChanged(view, s, start, count, after);
			}
		}

		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
			if (mTextWatcherEventListener != null) {
				mTextWatcherEventListener.onTextChanged(view, s, start, before, count);
			}
		}
	}

}
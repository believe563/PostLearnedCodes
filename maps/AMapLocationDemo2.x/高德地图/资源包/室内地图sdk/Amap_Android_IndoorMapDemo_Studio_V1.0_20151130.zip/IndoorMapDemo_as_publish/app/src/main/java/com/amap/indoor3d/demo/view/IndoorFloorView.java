package com.amap.indoor3d.demo.view;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.graphics.Color;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.gaode.indoormap.mapview.FloorInfo;
import com.gaode.indoormap.mapview.IndoorMapView;
import com.gaode.indoormap.mapview.IndoorMapView.IndoorFloorChangeListener;
import com.taobao.png.R;

/**
 * Created by wmh on 10/12/15.
 */
public class IndoorFloorView extends LinearLayout implements View.OnClickListener, IndoorFloorChangeListener {
    private LinearLayout mFloorList;
    private ScrollView mFloorScroller;
    private View mUp, mDown;
    private Handler mHandler = new Handler();
    private int mSelectIndex = 0;
    private List<View> mFloors = new ArrayList<View>();
    private IndoorMapView mIndoorView;
    public IndoorFloorView(Context context) {
        super(context);
    }
    public IndoorFloorView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }
	public void setIndoorView(IndoorMapView mIndoorView) {
		this.mIndoorView = mIndoorView;
//		loadAllFloorNames();
		if(mIndoorView!=null){
			this.mIndoorView.setFloorChangeListener(this);
			initFloors(mIndoorView.getFloorList());
		}
	}
    public void initFloors(List<FloorInfo> allFloorIds) {
//        mSwitchFloor = switchFloor;
        mFloors.clear();
        mFloorList.removeAllViews();
        int total = allFloorIds.size();
        LayoutParams lp = new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.CENTER_HORIZONTAL;
        LayoutInflater inflater = LayoutInflater.from(getContext());
        for(int i=total-1; i>=0; i--) {
        	FloorInfo info=allFloorIds.get(i);
            addFloor(inflater, lp,info.fl_index, info.fl_namecode);
        }
        ViewGroup.LayoutParams params = mFloorScroller.getLayoutParams();
        if(total <= MAX_ITEMS) {
            mUp.setVisibility(GONE);
            mDown.setVisibility(GONE);
            params.height = mItemHeight*total;
        } else {
            mUp.setVisibility(VISIBLE);
            mDown.setVisibility(VISIBLE);
            params.height = mItemHeight*MAX_ITEMS;
        }
        mFloorScroller.setLayoutParams(params);
        mSelectFloor=mIndoorView.getFloorID();
        hasSelected = true;
        refreshViews();
		if (total > 0) {
			this.setVisibility(View.VISIBLE);
		} else {
			this.setVisibility(View.INVISIBLE);
		}
    }
    public void setSelectFloor(int floor) {
        if(!hasLocated || mSelectFloor != floor) {
            mSelectFloor = floor;
            hasSelected = true;
            refreshViews();
        }
    }

    private void refreshViews() {
        int i=0;
        for(View floor : mFloors) {
            Holder holder = (Holder)floor.getTag();
            if(hasSelected) {
                if(holder.floor == mSelectFloor) {
                    mSelectIndex = i;
                    floor.setBackgroundColor(Color.parseColor("#4a92ff"));
                    holder.tv.setTextColor(Color.WHITE);
                    mFloorScroller.requestChildFocus(floor, floor);
                } else {
                    holder.tv.setTextColor(Color.parseColor("#777777"));
                    floor.setBackgroundColor(Color.WHITE);
                }
            }
            if(hasLocated) {
                if(holder.floor == mLocationFloor) {
                    holder.iv.setVisibility(VISIBLE);
                    if(holder.floor == mSelectFloor) {
                        holder.iv.setImageResource(R.drawable.indoor_flag_focused);
                    } else {
                        holder.iv.setImageResource(R.drawable.indoor_flag_unfocused);
                    }
                } else {
                    holder.iv.setVisibility(INVISIBLE);
                }
            }
            i++;
        }
    }

    private static final int MAX_ITEMS = 5;
    private int mItemHeight = 0;
    private void addFloor(LayoutInflater inflater, LayoutParams lp, int floor, String nona) {
        View view = inflater.inflate(R.layout.i_indoor_floor_item, null);
        Holder holder = new Holder();
        holder.iv = (ImageView)view.findViewById(R.id.indoor_floor_flag);
        holder.floor = floor;
        holder.tv = (TextView)view.findViewById(R.id.indoor_floor_nano);
        view.setTag(holder);
        if(0 == mItemHeight) {
            view.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            view.measure(0, 0);
            mItemHeight = view.getMeasuredHeight();
        }
        holder.tv.setText(nona);
        view.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                hasSelected = true;
                Holder tmp = (Holder)v.getTag();
                mSelectFloor = tmp.floor;
                refreshViews();
                //mSwitchFloor.switchFloor(tmp.floor, true);
                mIndoorView
				.loadMapFloor(tmp.floor);
            }
        });
        mFloorList.addView(view, lp);
        mFloors.add(view);
    }

    private boolean hasLocated = false;
    private int mLocationFloor = 0;
    private boolean hasSelected = false;
    private int mSelectFloor = 0;
    public void setLocationFLoor(int floor) {
        if(!hasLocated || mLocationFloor != floor) {
            hasLocated = true;
            mLocationFloor = floor;
            refreshViews();
        }
    }

    @Override
    protected void onFinishInflate() {
        findViewById(R.id.indoor_floor_up).setOnClickListener(this);
        findViewById(R.id.indoor_floor_down).setOnClickListener(this);
        mFloorList = (LinearLayout)findViewById(R.id.indoor_floor_list_container);
        mFloorScroller = (ScrollView)findViewById(R.id.indoor_floor_list);
        mUp = findViewById(R.id.indoor_floor_up);
        mDown = findViewById(R.id.indoor_floor_down);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.indoor_floor_down:
                onDown();
                break;
            case R.id.indoor_floor_up:
                onUp();
                break;
        }
    }

    private void onUp() {
        if(!hasSelected) {
            return;
        }
        if(mSelectIndex <= 0) {
            return;
        }
        mSelectIndex--;
        Holder holder = (Holder)mFloors.get(mSelectIndex).getTag();
        mSelectFloor = holder.floor;
        mFloors.get(mSelectIndex).performClick();
    }

    private void onDown() {
        if(!hasSelected) {
            return;
        }
        if(mSelectIndex >= mFloors.size()-1) {
            return;
        }
        mSelectIndex++;
        Holder holder = (Holder)mFloors.get(mSelectIndex).getTag();
        mSelectFloor = holder.floor;
        mFloors.get(mSelectIndex).performClick();
    }

    private class Holder {
        public ImageView iv;
        public TextView tv;
        public int floor;
    }

	@Override
	public void onFloorListChange() {
		// TODO Auto-generated method stub
		mHandler.post(new Runnable() {
			@Override
			public void run() {
				initFloors(mIndoorView.getFloorList());
			}
		});
	}
}
